/*
 * VATFLOW Tower Cab - what the tower sees happening on its runways, shared by the screens:
 *
 *   record()       takeoffs, landings and taxi-out times, learned from the VATSIM feed by the
 *                  strip bay feed (StripBay/StripBay.js, one reader for the cab) and kept in the
 *                  sim's storage per airport (OPS_<ICAO>), so every screen sees the same history
 *   taxiStats()    the average taxi-out time (first move at 7 kt to the takeoff roll, the way the
 *                  VATFLOW Taxi Monitor times it) over the last hour, and its trend
 *   depRunways() / arrRunways()   the runway ends in use: the VATSIM ATIS, else what departures /
 *                  arrivals used in the last 30 minutes, else the ends most into the METAR wind
 *   safety()       runway safety alerts for the ASDE-X: an arrival inside ~45 s of a runway that
 *                  is occupied, or an aircraft rolling with another on the runway ahead of it
 *   finals()       final approach spacing (ATPA-style): in-trail miles between arrivals on each
 *                  final against the wake turbulence minimum (FAA JO 7110.65 5-5-4)
 *   arrivalRunway() the runway an arrival lands on: the final it is on, else the active end
 *                  nearest it
 *   select() / selected()   the aircraft picked on a strip or a radar (VatflowStore "SELECT",
 *                  L:VATFLOW_SEL_REV), highlighted on the strips and both radars
 *
 * Aircraft here are {cs, lat, lon, alt (ft MSL), gs, hdg, type, dep, arr, route}: ac() makes one
 * from a VATSIM pilot, fromTarget() from a radar target (VatflowFeed.summarize). Runway ends
 * come from cfg.runways ({ids, a, b}) through ends(). Plain script, no modules.
 */
var VatflowOps = (function () {
  var NM_PER_DEG = 60;
  var TAXI_KT = 7;                 // moving this fast on the ground: taxiing (VATFLOW Taxi Monitor)
  var ROLL_KT = 40;                // rolling on a runway: a takeoff or landing roll
  var RWY_HALF_NM = 0.032;         // runway half width plus a wingspan (~60 m): "on the runway"
  var KEEP_MS = 30 * 60000;        // takeoffs / landings remembered for the runways in use
  var SAMPLE_MS = 3 * 3600000;     // taxi-out samples kept 3 hours
  var MAX_SAMPLES = 120;
  var SELECT_MS = 5 * 60000;       // a pick fades after 5 minutes

  // ---------------------------------------------------------------- aircraft and runways

  function ac(p) {
    var fp = p.flight_plan || {};
    return {
      cs: p.callsign, lat: p.latitude, lon: p.longitude, alt: p.altitude || 0, gs: p.groundspeed || 0, hdg: p.heading || 0,
      type: String(fp.aircraft_faa || fp.aircraft_short || fp.aircraft || "").toUpperCase(),
      dep: String(fp.departure || "").toUpperCase(), arr: String(fp.arrival || "").toUpperCase(),
      route: String(fp.route || "").replace(/\s+/g, " ").trim().toUpperCase()
    };
  }

  function fromTarget(t) {
    return { cs: t.callsign, lat: t.lat, lon: t.lon, alt: t.alt || 0, gs: t.gs || 0, hdg: t.hdg || 0,
      type: String(t.type || "").toUpperCase(), dep: t.dep || "", arr: t.arr || "", route: "" };
  }

  function xy(o, lat, lon) {
    return [(lon - o.lon) * NM_PER_DEG * Math.cos(o.lat * Math.PI / 180), (lat - o.lat) * NM_PER_DEG];
  }

  function distNm(o, lat, lon) { var v = xy(o, lat, lon); return Math.sqrt(v[0] * v[0] + v[1] * v[1]); }

  function hdgOff(a, b) { var d = Math.abs(((a - b) % 360 + 360) % 360); return d > 180 ? 360 - d : d; }

  /**
   * Both ends of each runway: {id, key ("01/19"), other, lat, lon (threshold), hdg (true, the
   * way you take off / land on it), lenNm}.
   */
  function ends(runways) {
    var out = [];
    (runways || []).forEach(function (r) {
      if (!r || !r.ids || !r.a || !r.b) return;
      var A = { lat: r.a[0], lon: r.a[1] }, v = xy(A, r.b[0], r.b[1]);
      var hdg = (Math.atan2(v[0], v[1]) * 180 / Math.PI + 360) % 360, len = Math.sqrt(v[0] * v[0] + v[1] * v[1]);
      var key = r.ids[0] + "/" + r.ids[1];
      out.push({ id: r.ids[0], other: r.ids[1], key: key, lat: r.a[0], lon: r.a[1], hdg: hdg, lenNm: len });
      out.push({ id: r.ids[1], other: r.ids[0], key: key, lat: r.b[0], lon: r.b[1], hdg: (hdg + 180) % 360, lenNm: len });
    });
    return out;
  }

  /** Where a point is against runway end e: along (nm past the threshold, the way e points) and across (nm, right +). */
  function rel(e, lat, lon) {
    var v = xy(e, lat, lon), h = e.hdg * Math.PI / 180;
    return { along: v[0] * Math.sin(h) + v[1] * Math.cos(h), across: v[0] * Math.cos(h) - v[1] * Math.sin(h) };
  }

  function agl(a, elevFt) { return (a.alt || 0) - (elevFt || 0); }

  /**
   * The runway an aircraft on the ground is on (inside its rectangle), as the end it faces
   * (the end it is travelling along when moving), or null.
   */
  function onRunway(es, a, elevFt) {
    if (agl(a, elevFt) > 150) return null;
    var best = null;
    for (var i = 0; i < es.length; i++) {
      var e = es[i], r = rel(e, a.lat, a.lon);
      if (Math.abs(r.across) > RWY_HALF_NM || r.along < -0.04 || r.along > e.lenNm + 0.04) continue;
      if (!best || hdgOff(a.hdg, e.hdg) < hdgOff(a.hdg, best.hdg)) best = e;
    }
    return best;
  }

  /** The runway end a departure is rolling on / just lifted off from, or null. */
  function takeoffEnd(es, a, elevFt) {
    var h = agl(a, elevFt);
    if (a.gs < ROLL_KT || h > 2000) return null;
    for (var i = 0; i < es.length; i++) {
      var e = es[i];
      if (hdgOff(a.hdg, e.hdg) > 20) continue;
      var r = rel(e, a.lat, a.lon);
      if (Math.abs(r.across) < 0.25 && r.along > -0.1 && r.along < e.lenNm + 3) return e;
    }
    return null;
  }

  /** The runway end an arrival is landing on (on the runway, rolling the way of an end), or null. */
  function landingEnd(es, a, elevFt) {
    if (a.gs < 25 || a.gs > 180 || agl(a, elevFt) > 120) return null;
    var e = onRunway(es, a, elevFt);
    return e && hdgOff(a.hdg, e.hdg) <= 25 ? e : null;
  }

  // ---------------------------------------------------------------- the recorder

  function empty() { return { deps: [], arrs: [], taxi: {}, samples: [] }; }

  /**
   * One look at the feed: notes taxi starts, takeoffs (with their taxi-out time) and landings.
   * ops: the stored history (empty() to start); pilots: the VATSIM feed's; info: {icao, arp,
   * elevFt, runways}. Returns ops (changed in place).
   */
  function record(ops, pilots, info, now) {
    ops = ops && ops.deps ? ops : empty();
    ops.taxi = ops.taxi || {};
    ops.samples = ops.samples || [];
    var es = ends(info.runways), here = {};
    for (var i = 0; i < (pilots || []).length; i++) {
      var p = pilots[i];
      if (!p || !p.flight_plan || typeof p.latitude !== "number") continue;
      var a = ac(p), h = agl(a, info.elevFt), d = distNm(info.arp, a.lat, a.lon);
      if (a.dep === info.icao) {
        here[a.cs] = true;
        var went = recent(ops.deps, a.cs, now, 20 * 60000);
        if (!went && !ops.taxi[a.cs] && d < 5 && h < 300 && a.gs >= TAXI_KT && a.gs < ROLL_KT) ops.taxi[a.cs] = { t: now };
        if (ops.taxi[a.cs]) ops.taxi[a.cs].seen = now;
        var off = !went && d < 6 ? takeoffEnd(es, a, info.elevFt) : null;
        if (off) {
          var roll = rollStart(a, h, now);
          ops.deps.push({ cs: a.cs, end: off.id, t: roll, type: a.type, route: a.route });
          var tx = ops.taxi[a.cs];
          if (tx) {
            var sec = Math.round((roll - tx.t) / 1000);
            if (sec >= 60 && sec <= 5400) ops.samples.push({ cs: a.cs, t: roll, sec: sec });
            delete ops.taxi[a.cs];
          }
        }
      }
      if (a.arr === info.icao && d < 6) {
        var land = landingEnd(es, a, info.elevFt);
        if (land && !recent(ops.arrs, a.cs, now, 20 * 60000)) ops.arrs.push({ cs: a.cs, end: land.id, t: now, type: a.type });
      }
    }
    ops.deps = ops.deps.filter(function (x) { return now - x.t < KEEP_MS; }).slice(-30);
    ops.arrs = ops.arrs.filter(function (x) { return now - x.t < KEEP_MS; }).slice(-30);
    ops.samples = ops.samples.filter(function (x) { return now - x.t < SAMPLE_MS; }).slice(-MAX_SAMPLES);
    for (var cs in ops.taxi) {
      var tx2 = ops.taxi[cs];
      if (now - tx2.t > 90 * 60000 || (!here[cs] && now - (tx2.seen || tx2.t) > 3 * 60000)) delete ops.taxi[cs];
    }
    return ops;
  }

  function recent(list, cs, now, ms) {
    for (var i = list.length - 1; i >= 0; i--) if (list[i].cs === cs && now - list[i].t < ms) return list[i];
    return null;
  }

  /**
   * When the takeoff roll started, from one look: rolling (about 3 kt a second from a stop),
   * or airborne (about 35 s on the runway, then 30 ft a second up).
   */
  function rollStart(a, h, now) {
    var back = h < 100 ? a.gs / 3 : 35 + h / 30;
    return Math.round(now - Math.min(150, back) * 1000);
  }

  /**
   * Taxi-out times: {avg, n} over the last hour (seconds), prev (the hour before), trend
   * ("UP" / "DOWN" / "" when they differ by a minute or more), and taxiing: [{cs, sec}] for
   * the aircraft taxiing out now (longest first).
   */
  function taxiStats(ops, now) {
    var cur = [], prev = [];
    ((ops && ops.samples) || []).forEach(function (s) {
      var age = now - s.t;
      if (age < 3600000) cur.push(s.sec); else if (age < 7200000) prev.push(s.sec);
    });
    function mean(v) { var t = 0; v.forEach(function (x) { t += x; }); return v.length ? Math.round(t / v.length) : null; }
    var avg = mean(cur), before = mean(prev), trend = "";
    if (avg !== null && before !== null && Math.abs(avg - before) >= 60) trend = avg > before ? "UP" : "DOWN";
    var taxiing = [];
    for (var cs in (ops && ops.taxi) || {}) taxiing.push({ cs: cs, sec: Math.round((now - ops.taxi[cs].t) / 1000) });
    taxiing.sort(function (a, b) { return b.sec - a.sec; });
    return { avg: avg, n: cur.length, prev: before, trend: trend, taxiing: taxiing };
  }

  // ---------------------------------------------------------------- runways in use

  var RWY_RE = /^(0?[1-9]|[12]\d|3[0-6])([LCR]?)$/;
  function normRwy(t) {
    var m = RWY_RE.exec(String(t || "").toUpperCase());
    return m ? (m[1].length === 1 ? "0" + m[1] : m[1]) + m[2] : "";
  }

  /**
   * The runways an ATIS says are in use: {arr: [ids], dep: [ids]}. In each sentence a runway
   * goes with the landing / approach or departure word before it (or the first one after it:
   * "RWY 1 FOR LANDING AND DEPARTURES" both); "RWY 01 IN USE" alone is both. Only ids in valid
   * (when given) count.
   */
  var ARR_W = /^(LDG|LNDG|LANDING|LAND|ARR|ARRIVALS?|ARRIVING|APCHS?|APPROACH(ES)?|ILS|RNAV|RNP|VISUAL|LOC|VOR)$/;
  var DEP_W = /^(DEPG|DEPTG|DEPARTING|DEPARTURES?|DEP|DEPS|TKOF|TAKEOFF|TAKEOFFS)$/;
  function atisRunways(text, valid) {
    var out = { arr: [], dep: [] };
    function add(kind, id) { if (out[kind].indexOf(id) < 0) out[kind].push(id); }
    var t = String(text || "").toUpperCase().replace(/\bRY\b/g, "RWY").replace(/\bRUNWAYS?\b/g, "RWY").replace(/\bRWYS\b/g, "RWY")
      .replace(/\bTAKE OFF\b/g, "TAKEOFF");
    t.split(/\.(?!\d)|\.\.\.|;/).forEach(function (s) {
      if (!/\bRWY\b|\bILS\b|\bRNAV\b|\bVISUAL\b|\bAPCH\b|\bAPPROACH/.test(s)) return;
      var cur = null, pending = [], carried = [], since = 0;
      s.replace(/[,/&]/g, " ").split(/\s+/).forEach(function (w) {
        var kind = ARR_W.test(w) ? "arr" : DEP_W.test(w) ? "dep" : null;
        if (kind) {
          if (pending.length) { carried = pending; pending = []; }
          else if (since) carried = [];
          carried.forEach(function (id) { add(kind, id); });
          cur = kind;
          since = 0;
          return;
        }
        var id = normRwy(w);
        if (!id || (valid && valid.indexOf(id) < 0)) return;
        since++;
        if (cur) add(cur, id); else pending.push(id);
      });
      if (pending.length && /\bIN USE\b|\bACTIVE\b/.test(s)) pending.forEach(function (id) { add("arr", id); add("dep", id); });
    });
    return out;
  }

  function intoWind(es, wind) {
    var dir = wind && parseInt(wind.dir, 10);
    if (!wind || !(wind.kt >= 5) || isNaN(dir)) return [];
    var score = function (e) { return Math.cos((dir - e.hdg) * Math.PI / 180); }, best = -2;
    es.forEach(function (e) { best = Math.max(best, score(e)); });
    return es.filter(function (e) { return score(e) > 0 && score(e) >= best - 0.03; });
  }

  function inUse(es, kind, ops, atisText, wind, now) {
    var ids = es.map(function (e) { return e.id; });
    var a = atisRunways(atisText, ids)[kind];
    if (a.length) return { ids: a, src: "ATIS" };
    var used = [];
    (((ops || {})[kind === "dep" ? "deps" : "arrs"]) || []).forEach(function (x) {
      if (now - x.t < KEEP_MS && used.indexOf(x.end) < 0 && ids.indexOf(x.end) >= 0) used.push(x.end);
    });
    if (used.length) return { ids: used, src: "IN USE" };
    var w = intoWind(es, wind).map(function (e) { return e.id; });
    if (w.length) return { ids: w, src: "WIND" };
    return { ids: ids, src: "" };
  }

  /** Departure runway ends in use: {ids, src: "ATIS" | "IN USE" | "WIND" | ""}. */
  function depRunways(es, ops, atisText, wind, now) { return inUse(es, "dep", ops, atisText, wind, now); }
  /** Arrival runway ends in use, the same way. */
  function arrRunways(es, ops, atisText, wind, now) { return inUse(es, "arr", ops, atisText, wind, now); }

  /** Headwind (+) / tailwind (-) and crosswind (from the right +), kt, for a runway end and a METAR wind (true). */
  function components(e, wind) {
    var dir = wind && parseInt(wind.dir, 10);
    if (!wind || isNaN(dir)) return null;
    var a = (dir - e.hdg) * Math.PI / 180, kt = wind.kt || 0, g = wind.gust || 0;
    return { head: Math.round(kt * Math.cos(a)), cross: Math.round(kt * Math.sin(a)), gustCross: g ? Math.round(g * Math.sin(a)) : null };
  }

  // ---------------------------------------------------------------- wake turbulence

  var HEAVY = ("A124 A225 A306 A30B A310 A332 A333 A337 A338 A339 A342 A343 A345 A346 A359 A35K A388 " +
    "B703 B741 B742 B743 B744 B748 B74D B74R B74S B762 B763 B764 B772 B773 B778 B779 B77L B77W B788 B789 B78X " +
    "C135 C141 C17 C5 C5M DC10 E3CF E3TF E6 IL76 IL96 K35R KC10 L101 MD11 A400 B52").split(" ");
  var SUPER = ["A388", "A225", "A124"];
  var SMALL_RE = /^(C1\d\d|C2[0-9][0-9RT]?|C3\d\d|C4\d\d|C5[0-6]\d|C25[A-C]|C510|C68A|PA\d\d|P28[A-Z]|P32R|P46T|SR2[02]|S22T|BE\d\d|BE\d\dT|B350|DA\d\d|DA4[02]|DA62|M20[A-Z]|TBM\d|PC12|PC24|E50P|E55P|SF50|EA50|LJ\d\d|HDJT|AA5|DV20|RV\d+|BT36|C77R|C82[RS]?|P210|PA46|DHC[26]|BN2P|GLID)$/;

  /** "super" | "heavy" | "B757" | "small" | "large" for a filed type ("H/B744/L" too). */
  function wakeCat(raw) {
    var t = String(raw || "").toUpperCase().replace(/^[HMLJS]\//, "").split("/")[0].trim();
    if (SUPER.indexOf(t) >= 0) return "super";
    if (HEAVY.indexOf(t) >= 0) return "heavy";
    if (/^B75[23]$/.test(t)) return "B757";
    if (SMALL_RE.test(t)) return "small";
    return "large";
  }

  /** In-trail miles behind a leader on final (FAA JO 7110.65 5-5-4: wake minima, else 3 NM radar). */
  function wakeNm(leadType, followType) {
    var l = wakeCat(leadType), f = wakeCat(followType);
    var T = {
      super: { super: 3, heavy: 6, B757: 7, large: 7, small: 8 },
      heavy: { super: 3, heavy: 4, B757: 5, large: 5, small: 6 },
      B757: { small: 4 }
    };
    return Math.max(3, (T[l] && T[l][f]) || 3);
  }

  // ---------------------------------------------------------------- finals and arrivals

  /** Arrival on the final of end e: aligned, before the threshold, under 4,000 ft, inside 12 nm. */
  function onFinal(e, a, elevFt) {
    var h = agl(a, elevFt);
    if (h < 0 || h > 4000 || a.gs < 60 || hdgOff(a.hdg, e.hdg) > 30) return null;
    var r = rel(e, a.lat, a.lon);
    if (r.along > 0.2 || r.along < -12 || Math.abs(r.across) > 0.5 + 0.08 * -r.along) return null;
    return { dist: Math.max(0, -r.along), across: r.across };
  }

  /**
   * The one final an arrival is on: of the ends it is lined up with, the one it is most nearly
   * on the centreline of (close parallels such as KATL 08L / 08R are both "aligned" from a few
   * miles out). -> {e, dist, across} or null.
   */
  function finalOf(es, a, elevFt) {
    var best = null;
    es.forEach(function (e) {
      var f = onFinal(e, a, elevFt);
      if (f && (!best || Math.abs(f.across) < Math.abs(best.across))) best = { e: e, dist: f.dist, across: f.across };
    });
    return best;
  }

  /**
   * Final approach spacing: per runway end, the arrivals on its final nearest first, and each
   * pair's in-trail gap against its wake minimum. -> {pairs: [{end, lead, follow, gap, req,
   * level: "ok" | "amber" (within half a mile of it) | "red" (under it)}], on: {CS: {end, dist}}}
   */
  function finals(es, list, elevFt) {
    var on = {}, pairs = [];
    (list || []).forEach(function (a) {
      var f = finalOf(es, a, elevFt);
      if (f) on[a.cs] = { end: f.e.id, dist: f.dist };
    });
    es.forEach(function (e) {
      var q = (list || []).filter(function (a) { return on[a.cs] && on[a.cs].end === e.id; })
        .sort(function (x, y) { return on[x.cs].dist - on[y.cs].dist; });
      for (var i = 1; i < q.length; i++) {
        var lead = q[i - 1], fol = q[i], gap = on[fol.cs].dist - on[lead.cs].dist, req = wakeNm(lead.type, fol.type);
        pairs.push({ end: e.id, lead: lead.cs, follow: fol.cs, gap: Math.round(gap * 10) / 10, req: req,
          level: gap < req ? "red" : gap < req + 0.5 ? "amber" : "ok" });
      }
    });
    return { pairs: pairs, on: on };
  }

  /**
   * The runway an arrival lands on: {id, sure}: the final it is on (sure), else of the active
   * arrival ends (arrIds) the one whose threshold is nearest it, or null.
   */
  function arrivalRunway(es, a, arrIds, onMap) {
    if (onMap && onMap[a.cs]) return { id: onMap[a.cs].end, sure: true };
    var best = null, bd = Infinity;
    es.forEach(function (e) {
      if (arrIds && arrIds.length && arrIds.indexOf(e.id) < 0) return;
      var d = distNm(e, a.lat, a.lon);
      if (d < bd) { bd = d; best = e; }
    });
    return best ? { id: best.id, sure: false } : null;
  }

  // ---------------------------------------------------------------- runway safety

  /**
   * Runway safety alerts (ASDE-X style) for the aircraft in list:
   *   ARR    an arrival on short final, within about 45 s of the threshold, while another
   *          aircraft is on that runway (any part of it, either direction)
   *   ROLL   an aircraft on a takeoff / landing roll with another one on the runway ahead of it
   * -> [{id, kind, rwy ("01/19"), cs: [moving, other], text}], the same id while it lasts.
   */
  function safety(es, list, elevFt) {
    var out = [], occ = {}, seen = {};
    (list || []).forEach(function (a) {             // on every runway it is inside (an intersection is on both)
      var e = onRunway(es, a, elevFt);
      if (!e) return;
      es.forEach(function (x) {
        if (x.id !== x.key.split("/")[0] || (occ[x.key] || []).some(function (o) { return o.a === a; })) return;
        var r = rel(x, a.lat, a.lon);
        if (Math.abs(r.across) > RWY_HALF_NM || r.along < -0.04 || r.along > x.lenNm + 0.04) return;
        (occ[x.key] = occ[x.key] || []).push({ a: a, e: x.key === e.key ? e : x });
      });
    });
    function add(kind, rwy, mover, other, text) {
      var id = kind + ":" + rwy + ":" + mover + ":" + other;
      if (seen[id]) return;
      seen[id] = true;
      out.push({ id: id, kind: kind, rwy: rwy, cs: [mover, other], text: text });
    }
    // arrivals about to land on an occupied runway
    (list || []).forEach(function (a) {
      var h = agl(a, elevFt);
      if (h < 20 || h > 900 || a.gs < 60) return;
      // the one runway it is landing on: lined up with it, most nearly on its centreline (a close
      // parallel's final is in reach too, but the aircraft isn't landing there)
      var e = null, best = Infinity;
      es.forEach(function (x) {
        if (hdgOff(a.hdg, x.hdg) > 20) return;
        var r = rel(x, a.lat, a.lon), toGo = -r.along;
        if (toGo < -0.05 || toGo > 2.5 || Math.abs(r.across) > 0.25 + 0.1 * Math.max(0, toGo)) return;
        if (toGo / Math.max(60, a.gs) * 3600 > 45) return;
        if (Math.abs(r.across) < best) { best = Math.abs(r.across); e = x; }
      });
      if (!e || !occ[e.key]) return;
      occ[e.key].forEach(function (o) {
        if (o.a.cs === a.cs) return;
        add("ARR", e.key, a.cs, o.a.cs, a.cs + " ARR RWY " + e.id + " - " + o.a.cs + " ON RWY " + e.key);
      });
    });
    // a roll with someone on the runway ahead
    for (var key in occ) {
      var on = occ[key];
      on.forEach(function (m) {
        if (m.a.gs < ROLL_KT || hdgOff(m.a.hdg, m.e.hdg) > 30) return;      // rolling along this runway (not across it)
        var mr = rel(m.e, m.a.lat, m.a.lon);
        on.forEach(function (o) {
          if (o.a.cs === m.a.cs) return;
          var orr = rel(m.e, o.a.lat, o.a.lon);
          if (orr.along <= mr.along || (o.a.gs >= ROLL_KT && hdgOff(o.a.hdg, m.e.hdg) < 30)) return;   // behind, or rolling away too
          add("ROLL", key, m.a.cs, o.a.cs, m.a.cs + " ROLLING RWY " + m.e.id + " - " + o.a.cs + " ON RWY AHEAD");
        });
      });
    }
    return out;
  }

  // ---------------------------------------------------------------- the aircraft picked

  function selRev() {
    if (typeof SimVar === "undefined") return typeof VatflowStore !== "undefined" ? VatflowStore.get("SELECT_REV", 0) : 0;
    return SimVar.GetSimVarValue("L:VATFLOW_SEL_REV", "number") || 0;
  }

  /** Picks callsign cs on every screen (null clears it). */
  function select(cs) {
    if (typeof VatflowStore === "undefined") return;
    VatflowStore.set("SELECT", cs ? { cs: cs, t: Date.now() } : null);
    var r = (selRev() + 1) % 1000000;
    if (typeof SimVar === "undefined") VatflowStore.set("SELECT_REV", r);
    else SimVar.SetSimVarValue("L:VATFLOW_SEL_REV", "number", r);
  }

  var selCache = { rev: -1, at: 0, cs: null };
  /** The callsign picked (on any screen) in the last 5 minutes, or null. Cheap to call every frame. */
  function selected() {
    if (typeof VatflowStore === "undefined") return null;
    var r = selRev(), now = Date.now();
    if (r !== selCache.rev || now - selCache.at > 5000) {
      var s = VatflowStore.get("SELECT", null);
      selCache = { rev: r, at: now, cs: s && s.cs && now - s.t < SELECT_MS ? s.cs : null, t: s ? s.t : 0 };
    }
    return selCache.cs && now - selCache.t < SELECT_MS ? selCache.cs : null;
  }

  return {
    TAXI_KT: TAXI_KT, ROLL_KT: ROLL_KT, ac: ac, fromTarget: fromTarget, ends: ends, rel: rel, onRunway: onRunway,
    takeoffEnd: takeoffEnd, landingEnd: landingEnd, empty: empty, record: record, rollStart: rollStart, taxiStats: taxiStats,
    normRwy: normRwy, atisRunways: atisRunways, depRunways: depRunways, arrRunways: arrRunways, components: components,
    wakeCat: wakeCat, wakeNm: wakeNm, onFinal: onFinal, finals: finals, arrivalRunway: arrivalRunway, safety: safety,
    select: select, selected: selected, hdgOff: hdgOff, distNm: distNm
  };
})();

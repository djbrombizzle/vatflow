/*
 * VATFLOW Tower Cab - ASDE-X surface display (in-cab overhead screen $SCREEN_ASDEX).
 *
 * Map of the field in ASDE-X colours (teal water, grey field, dark movement area, black
 * runways, light-grey terminals), turned so its top is the view out of the window the
 * monitor hangs in front of (it follows the monitor round the ceiling track and its
 * swivel), with a north arrow. Live VATSIM traffic on
 * and near the airport (ground movements plus arrivals/departures below
 * cfg.asdex.maxAglFt) as heading-oriented targets with callsign/type blocks.
 *
 * Runway safety (common/twr-ops.js VatflowOps.safety): an arrival within ~45 s of a runway
 * someone is on, or a roll with someone on the runway ahead, turns both targets red and puts
 * up the alert box with its alarm (Screen/Screen.js alertBox). Arrivals' blocks show the
 * runway they land on (the final they are on; "?" after it: the active arrival runway
 * nearest them). The aircraft picked on a strip or radar (VatflowOps.selected) gets a cyan ring;
 * tapping a target picks it.
 *
 * AsdexView is plain canvas code (also used by preview/index.html); the MSFS
 * wrapper at the bottom only exists when BaseInstrument is defined.
 */
var AsdexView = (function () {
  var NM = 1852;
  var C = {
    water: "#005a72",
    land: "#4d4d4d",
    apron: "#3a3a3a",
    taxiway: "#2b2b2b",
    runway: "#060606",
    building: "#6a6a6a",
    target: "#ffffff",
    airborne: "#5fd4ff",
    block: "#ffffff",
    blockAir: "#5fd4ff",
    text: "#d8f0ff",
    label: "#c8c8c8",
    labelHalo: "#1a1a1a",
    alert: "#ff3030",
    selected: "#29d3ff"
  };
  var LABEL_EVERY_PX = 380;   // a long taxiway gets a label about this often along it
  var LABEL_SAME_PX = 230;    // no two labels of the same taxiway closer than this
  var LABEL_ANY_PX = 30;      // nor any two labels on top of each other

  function AsdexView(canvas, cfg, maps) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.cfg = cfg;
    this.map = maps && maps.asdex;
    this.names = maps && maps.asdex;   // where the taxiway names come from (OpenStreetMap), whichever map is shown
    this.targets = {};
    this.feedMs = 0;
    this.error = null;
    this.upHdg = 0;          // degrees true at the top of the screen
    this.view = null;        // zoom / pan (VatflowViewCtl), set by the screen host
    this.alerts = [];        // runway safety alerts in the latest traffic
    this.hot = {};           // callsigns in an alert
    this.hits = [];          // [{cs, x, y}] where each target was drawn (tap to pick)
    this.fit();
  }

  /** Zoom / pan control (VatflowViewCtl) applied on top of the fit. */
  AsdexView.prototype.setView = function (v) { this.view = v; this.fit(); };

  AsdexView.colors = C;
  // vNAS ASDE-X map colours when a polygon has none
  var VC = { bg: "#141a1c", runway: "#4d4d4d", taxiway: "#424242", apron: "#4d4d4d", structure: "#5d6060" };

  /** Swaps the map (maps.asdex: built-in / OpenStreetMap, or an ARTCC ASDE-X map from VatflowVnas.toAsdex). */
  AsdexView.prototype.setMap = function (asdex) {
    this.map = asdex || null;
    if (asdex && !asdex.vnas && asdex.taxiways) this.names = asdex;
    this.fit();
  };

  /** Turns the map so heading h (degrees true) is at the top; refits when it changes. */
  AsdexView.prototype.setUp = function (h) {
    h = ((h % 360) + 360) % 360;
    if (Math.abs(h - this.upHdg) < 0.5) return;
    this.upHdg = h;
    this.fit();
  };

  /** Meters (x east, y north) turned so upHdg points up (still x right, y up). */
  AsdexView.prototype.turn = function (x, y) {
    var a = this.upHdg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
    return { x: x * c - y * s, y: x * s + y * c };
  };

  /** Scale/offset so the (turned) field outline fills the canvas. */
  AsdexView.prototype.fit = function () {
    var W = this.canvas.width, H = this.canvas.height, m = this.cfg.asdex.marginPx;
    var minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    var rings = this.map && this.map.land.length ? this.map.land : null;
    if (rings) {
      for (var r = 0; r < rings.length; r++) {
        for (var i = 0; i < rings[r].length; i += 2) {
          var q = this.turn(rings[r][i], rings[r][i + 1]);
          minX = Math.min(minX, q.x); maxX = Math.max(maxX, q.x);
          minY = Math.min(minY, q.y); maxY = Math.max(maxY, q.y);
        }
      }
    } else {
      minX = minY = -2000; maxX = maxY = 2000;
    }
    this.scale = Math.min((W - 2 * m) / (maxX - minX), (H - 2 * m - 40) / (maxY - minY));
    this.cx = W / 2 - this.scale * (minX + maxX) / 2;
    this.cy = H / 2 + 20 + this.scale * (minY + maxY) / 2;
    if (this.view) {
      var v = this.view.apply(this.scale, this.cx, this.cy);
      this.scale = v.scale; this.cx = v.cx; this.cy = v.cy;
    }
  };

  /** Meters (x east, y north from the ARP) -> canvas pixels. */
  AsdexView.prototype.px = function (x, y) {
    var q = this.turn(x, y);
    return { x: this.cx + q.x * this.scale, y: this.cy - q.y * this.scale };
  };

  AsdexView.prototype.setData = function (summary) {
    var base = Date.parse(summary.updated);
    if (isNaN(base)) base = Date.now();
    this.targets = {};
    for (var i = 0; i < summary.traffic.length; i++) {
      var t = summary.traffic[i];
      if (this.visible(t)) this.targets[t.callsign] = { t: t, baseMs: base };
    }
    this.feedMs = base;
    this.source = summary.source || "VATSIM";
    this.simCount = summary.simCount;
    this.error = null;
    this.checkRunways(summary.traffic);
  };

  /** Runway safety alerts and arrival runways for the traffic near the field. */
  AsdexView.prototype.checkRunways = function (traffic) {
    if (typeof VatflowOps === "undefined") return;
    var O = VatflowOps, cfg = this.cfg, es = O.ends(cfg.runways);
    var list = (traffic || []).filter(function (t) { return t.distNm <= 8 && typeof t.lat === "number"; }).map(O.fromTarget);
    this.alerts = O.safety(es, list, cfg.elevFt);
    var hot = {};
    this.alerts.forEach(function (a) { hot[a.cs[0]] = hot[a.cs[1]] = true; });
    this.hot = hot;
    var ops = typeof VatflowStore !== "undefined" ? VatflowStore.get("TWROPS_" + cfg.icao, null) : null;
    var arrIds = ops && ops.arr ? ops.arr.ids : null, on = O.finals(es, list, cfg.elevFt).on, rw = {};
    list.forEach(function (a) {
      if (a.arr !== cfg.icao || a.alt - cfg.elevFt < 50) return;
      var r = O.arrivalRunway(es, a, arrIds, on);
      if (r) rw[a.cs] = r.id + (r.sure ? "" : "?");
    });
    this.arrRwy = rw;
  };

  /** Alerts silenced with the alert box (on every screen) stay silent until they are over. */
  AsdexView.prototype.isMuted = function (id) {
    if (!this.muted || Date.now() - (this.mutedAt || 0) > 3000) {
      this.muted = (typeof VatflowStore !== "undefined" && VatflowStore.get("RWY_MUTED", null)) || {};
      this.mutedAt = Date.now();
    }
    return !!this.muted[id];
  };

  AsdexView.prototype.muteAlerts = function () {
    var m = {};
    (this.alerts || []).forEach(function (a) { m[a.id] = true; });     // only the alerts up now (older ones are over)
    this.muted = m;
    this.mutedAt = Date.now();
    if (typeof VatflowStore !== "undefined") VatflowStore.set("RWY_MUTED", m);
  };

  /** The alarm (sound.xml loops vatflow_rwyalert.wav while L:VATFLOW_RWY_ALERT is 1). */
  AsdexView.prototype.setAlarm = function (on) {
    if (typeof SimVar === "undefined" || on === this.alarm) return;
    this.alarm = on;
    SimVar.SetSimVarValue("L:VATFLOW_RWY_ALERT", "number", on ? 1 : 0);
  };

  /** The callsign drawn nearest canvas point (x, y), within 30 px, or null. */
  AsdexView.prototype.hit = function (x, y) {
    var best = null, bd = 30;
    for (var i = 0; i < this.hits.length; i++) {
      var h = this.hits[i], d = Math.sqrt((h.x - x) * (h.x - x) + (h.y - y) * (h.y - y));
      if (d < bd) { bd = d; best = h.cs; }
    }
    return best;
  };

  AsdexView.prototype.setError = function (err) {
    this.error = String(err && err.message ? err.message : err);
  };

  AsdexView.prototype.visible = function (t) {
    var a = this.cfg.asdex;
    return t.distNm <= a.maxDistNm && t.alt - this.cfg.elevFt <= a.maxAglFt;
  };

  /** Dead-reckoned position in meters (capped at 20 s; ground targets barely move). */
  AsdexView.prototype.positionAt = function (e, nowMs) {
    var t = e.t;
    var dt = Math.min(20, Math.max(0, (nowMs - e.baseMs) / 1000));
    var d = (t.gs >= 3 ? t.gs : 0) * dt / 3600 * NM;
    var h = t.hdg * Math.PI / 180;
    return { x: t.x * NM + d * Math.sin(h), y: t.y * NM + d * Math.cos(h) };
  };

  AsdexView.prototype.drawMap = function (ctx) {
    var self = this, m = this.map, i;
    var proj = function (x, y) { return self.px(x, y); };
    ctx.fillStyle = m && m.vnas ? VC.bg : C.water;
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    if (!m) return;
    if (m.vnas) {          // ARTCC ASDE-X map: filled polygons in the facility's colours
      for (i = 0; i < m.polys.length; i++) {
        var pg = m.polys[i];
        ctx.fillStyle = pg.c || VC[pg.k] || VC.apron;
        VatflowDraw.path(ctx, pg.p, proj, true);
        ctx.fill();
      }
      return;
    }
    ctx.fillStyle = C.land;
    for (i = 0; i < m.land.length; i++) { VatflowDraw.path(ctx, m.land[i], proj, true); ctx.fill(); }
    ctx.fillStyle = C.apron;
    for (i = 0; i < m.aprons.length; i++) { VatflowDraw.path(ctx, m.aprons[i], proj, true); ctx.fill(); }
    ctx.strokeStyle = C.taxiway;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    for (i = 0; i < m.taxiways.length; i++) {
      ctx.lineWidth = Math.max(2, m.taxiways[i].w * this.scale);
      VatflowDraw.path(ctx, m.taxiways[i].p, proj, false);
      ctx.stroke();
    }
    ctx.strokeStyle = C.runway;
    ctx.fillStyle = C.runway;
    ctx.lineCap = "butt";
    for (i = 0; i < m.runways.length; i++) {
      var rw = m.runways[i];
      if (rw.c) {  // closed outline (stopway/runway area): fill it
        VatflowDraw.path(ctx, rw.p, proj, true);
        ctx.fill();
      } else {     // centerline: stroke at the runway's real width
        ctx.lineWidth = Math.max(4, rw.w * this.scale);
        VatflowDraw.path(ctx, rw.p, proj, false);
        ctx.stroke();
      }
    }
    ctx.fillStyle = C.building;
    for (i = 0; i < m.buildings.length; i++) { VatflowDraw.path(ctx, m.buildings[i], proj, true); ctx.fill(); }
  };

  /**
   * Where the taxiway names go (canvas pixels): along each named taxiway (OpenStreetMap's
   * ref: A, B1 ...) every LABEL_EVERY_PX of its length on screen, at least one in the middle
   * of a piece long enough to carry it, never two of the same taxiway within LABEL_SAME_PX
   * or any two within LABEL_ANY_PX, and only on screen. [{t, x, y}]
   */
  AsdexView.prototype.labelSpots = function () {
    var m = this.names, out = [], W = this.canvas.width, H = this.canvas.height, self = this;
    if (!m || !m.taxiways) return out;
    function free(t, x, y) {
      if (x < 12 || y < 40 || x > W - 12 || y > H - 40) return false;
      for (var k = 0; k < out.length; k++) {
        var d = Math.abs(out[k].x - x) + Math.abs(out[k].y - y);
        if (d < LABEL_ANY_PX * 1.4 || (out[k].t === t && d < LABEL_SAME_PX)) return false;
      }
      return true;
    }
    // longest pieces first, so a taxiway's label sits on its main stretch
    var tws = m.taxiways.filter(function (tw) { return tw.ref && tw.p && tw.p.length >= 4; }).map(function (tw) {
      var pts = [], len = 0;
      for (var i = 0; i < tw.p.length; i += 2) {
        var q = self.px(tw.p[i], tw.p[i + 1]);
        if (pts.length) len += Math.hypot(q.x - pts[pts.length - 1].x, q.y - pts[pts.length - 1].y);
        pts.push(q);
      }
      return { t: tw.ref, pts: pts, len: len };
    }).sort(function (a, b) { return b.len - a.len; });
    tws.forEach(function (tw) {
      if (tw.len < 24 + 9 * tw.t.length) return;              // too short on screen to carry its name
      var n = Math.max(1, Math.floor(tw.len / LABEL_EVERY_PX));
      for (var k = 0; k < n; k++) {
        var at = tw.len * (k + 0.5) / n, run = 0;
        for (var i = 1; i < tw.pts.length; i++) {
          var a = tw.pts[i - 1], b = tw.pts[i], seg = Math.hypot(b.x - a.x, b.y - a.y);
          if (run + seg >= at) {
            var f = seg ? (at - run) / seg : 0, x = a.x + (b.x - a.x) * f, y = a.y + (b.y - a.y) * f;
            if (free(tw.t, x, y)) out.push({ t: tw.t, x: x, y: y });
            break;
          }
          run += seg;
        }
      }
    });
    return out;
  };

  /** Taxiway names, upright whichever way the map is turned, light grey with a dark edge. */
  AsdexView.prototype.drawLabels = function (ctx) {
    var spots = this.labelSpots();
    ctx.font = "bold 15px monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineJoin = "round";
    ctx.lineWidth = 4;
    ctx.strokeStyle = C.labelHalo;
    ctx.fillStyle = C.label;
    for (var i = 0; i < spots.length; i++) {
      ctx.strokeText(spots[i].t, spots[i].x, spots[i].y);
      ctx.fillText(spots[i].t, spots[i].x, spots[i].y);
    }
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    return spots.length;
  };

  /** Aircraft-shaped arrow pointing along heading. */
  function arrow(ctx, x, y, hdg, size) {
    var a = hdg * Math.PI / 180;
    var s = Math.sin(a), c = Math.cos(a);
    function pt(fx, fy) { return { x: x + fx * c - fy * s, y: y + fx * s + fy * c }; }
    // local frame: forward = -y (up) before rotation
    var pts = [pt(0, -size), pt(size * 0.6, size * 0.7), pt(0, size * 0.35), pt(-size * 0.6, size * 0.7)];
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
    ctx.closePath();
    ctx.fill();
  }

  AsdexView.prototype.draw = function (nowMs, zuluSec) {
    var ctx = this.ctx, cfg = this.cfg, W = this.canvas.width, H = this.canvas.height;
    var CW = 12, mono = VatflowDraw.mono;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    this.drawMap(ctx);
    this.drawLabels(ctx);

    ctx.font = "18px monospace";
    ctx.textBaseline = "alphabetic";
    var n = 0, sel = typeof VatflowOps !== "undefined" ? VatflowOps.selected() : null, rw = this.arrRwy || {};
    var redOn = Math.floor(nowMs / 500) % 2 === 0;
    this.hits = [];
    for (var cs in this.targets) {
      var e = this.targets[cs], t = e.t;
      var p = this.positionAt(e, nowMs);
      var q = this.px(p.x, p.y);
      if (q.x < -40 || q.y < -40 || q.x > W + 40 || q.y > H + 40) continue;
      n++;
      var air = t.alt - cfg.elevFt > 150 && t.gs > 50, hot = this.hot && this.hot[cs];
      this.hits.push({ cs: cs, x: q.x, y: q.y });
      if (hot) {                                       // in a runway safety alert: red, flashing ring
        ctx.strokeStyle = C.alert;
        ctx.lineWidth = 3;
        if (redOn) { ctx.beginPath(); ctx.arc(q.x, q.y, 20, 0, Math.PI * 2); ctx.stroke(); }
      }
      if (sel === cs) {
        ctx.strokeStyle = C.selected;
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(q.x, q.y, 16, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.fillStyle = hot ? C.alert : air ? C.airborne : C.target;
      arrow(ctx, q.x, q.y, t.hdg - this.upHdg, 11);
      ctx.fillStyle = hot ? C.alert : sel === cs ? C.selected : air ? C.blockAir : C.block;
      mono(ctx, t.callsign, q.x + 14, q.y - 6, CW);
      mono(ctx, (t.type || "") + (air ? " " + VatflowFeed.pad(t.alt / 100, 3) : "") + (rw[cs] ? " " + rw[cs] : ""), q.x + 14, q.y + 14, CW);
    }

    // north arrow
    var nv = this.turn(0, 1), nx = W - 44, ny = 70;
    ctx.strokeStyle = C.text; ctx.fillStyle = C.text; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(nx, ny, 22, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(nx + nv.x * 18, ny - nv.y * 18);
    ctx.lineTo(nx - nv.x * 10 - nv.y * 7, ny + nv.y * 10 - nv.x * 7);
    ctx.lineTo(nx - nv.x * 10 + nv.y * 7, ny + nv.y * 10 + nv.x * 7);
    ctx.closePath(); ctx.fill();
    mono(ctx, "N", nx + nv.x * 33 - CW / 2, ny - nv.y * 33 + 6, CW);

    ctx.fillStyle = C.text;
    mono(ctx, "GROUND RADAR " + cfg.icao + (this.view && !this.view.isHome() ? "  ZOOM X" + this.view.zoom.toFixed(1) : "") +
      (this.rotManual ? "  ROT " + VatflowFeed.pad((((this.upHdg - (cfg.magVarDeg || 0)) % 360) + 360) % 360, 3) + "M" : ""), 14, 26, CW);
    if (typeof zuluSec === "number" && !isNaN(zuluSec)) {
      var z = VatflowDraw.zulu(zuluSec);
      var s = z.hh + z.mm + ":" + z.ss + "Z";
      mono(ctx, s, W - 14 - s.length * CW, 26, CW);
    }
    var age = this.feedMs ? Math.round((Date.now() - this.feedMs) / 1000) : null;
    var src = typeof VatflowTraffic !== "undefined" ? VatflowTraffic.source() : (this.source || "VATSIM");
    mono(ctx, this.error ? src + " " + this.error.toUpperCase() : (age === null ? src + " WAIT" : src + " " + age + "S TGT " + n +
      (src === "SIM" && this.simCount != null ? " OF " + this.simCount + " IN SIM" : "")), 14, H - 14, CW);
  };

  return AsdexView;
})();
// In the sim this view runs inside the screen host (Screen/Screen.js).

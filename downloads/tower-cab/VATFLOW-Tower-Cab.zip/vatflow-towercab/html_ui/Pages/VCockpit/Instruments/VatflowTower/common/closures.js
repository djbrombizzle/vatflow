/*
 * VATFLOW Tower Cab - runway and taxiway closures (the CLOSURES app, Closures/Closures.js).
 *
 * A closure is kept per airport in the sim's storage (VatflowStore CLOSURES_<ICAO>):
 *   { rwys: {"01/19": 1}, twys: [{id, ref, w, a: {x, y, hdg, i, s}, b: {...} | null}] }
 * Points are meters east (x) / north (y) of the ARP, on the taxiway centerline of the
 * ASDE-X map (maps.asdex.taxiways, OpenStreetMap); i is that taxiway's index in the map and
 * s the distance along it, so a closed stretch can follow the taxiway's curves.
 *
 * objects() turns the closures into the things to put in the sim:
 *   closed runway   a lighted X (vatflow_closure_x) just inside each threshold
 *   closed taxiway  a row of low-profile barricades with red lights across the taxiway at
 *                   each end, rows along both edges between them so the stretch is boxed in
 *                   (Matt, 2026-10-26), and inside a few construction vehicles, dirt and
 *                   rock piles and a porta potty (2026-10-27; random, but the same ones every
 *                   time for that closure)
 * The helper on the PC (placement/closures_helper.py, closures.bat) listens on
 * http://127.0.0.1:47640 and creates / removes those SimObjects through SimConnect. The cab
 * sends it the whole list whenever it changes and every few seconds checks it is there
 * (link()). Instrument pages can't create SimObjects themselves.
 */
var VatflowClosures = (function () {
  var M_PER_DEG = 111320;
  var HELPER = "http://127.0.0.1:47640";
  // 5 was a runway light cover test (2026-10-27, dropped): not reused, so an old helper can't mistake it
  var KINDS = { barricade: 1, closedX: 2, workTruck: 3, dumpTruck: 4, dirtPile: 6, rockPile: 7, portaPotty: 8 };
  var BARRICADE_M = 3.05;      // one low-profile barricade (10 ft)
  var RWY_W_M = 46;            // runway width when the map has none (150 ft)
  var X_IN_M = 45;             // lighted X this far inside the threshold
  var HIT_PAD_M = 12;          // a tap counts this far outside a runway / taxiway edge
  var SAME_POINT_M = 25;       // second tap this close to the first: a one-spot closure
  var SIDE_MAX = 240;          // barricades along the edges of one closure; longer: gaps between them
  var MAX_OBJECTS = 400;

  function deg(r) { return ((r * 180 / Math.PI) % 360 + 360) % 360; }
  function key(icao) { return "CLOSURES_" + (icao || "KDCA"); }

  function empty() { return { rwys: {}, twys: [], rev: 0 }; }

  function load(icao) {
    var st = typeof VatflowStore !== "undefined" ? VatflowStore.get(key(icao), null) : null;
    if (!st || typeof st !== "object") return empty();
    st.rwys = st.rwys || {};
    delete st.dark;                 // the dropped lights-off test
    st.twys = st.twys || [];
    st.rev = st.rev || 0;
    return st;
  }

  function save(icao, st) {
    st.rev = (st.rev || 0) + 1;
    if (typeof VatflowStore !== "undefined") VatflowStore.set(key(icao), st);
  }

  /** lat/lon -> meters east / north of the ARP (flat earth, fine across an airport). */
  function toM(arp, lat, lon) {
    return { x: (lon - arp.lon) * M_PER_DEG * Math.cos(arp.lat * Math.PI / 180), y: (lat - arp.lat) * M_PER_DEG };
  }

  function toLatLon(arp, x, y) {
    return { lat: arp.lat + y / M_PER_DEG, lon: arp.lon + x / (M_PER_DEG * Math.cos(arp.lat * Math.PI / 180)) };
  }

  /** Nearest point to (x, y) on a flat [x0, y0, x1, y1, ...] line: {d, x, y, hdg, s}. */
  function nearest(p, x, y) {
    var best = null, run = 0;
    for (var k = 0; k + 3 < p.length; k += 2) {
      var ax = p[k], ay = p[k + 1], dx = p[k + 2] - ax, dy = p[k + 3] - ay, len2 = dx * dx + dy * dy;
      var len = Math.sqrt(len2);
      var t = len2 > 0 ? Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / len2)) : 0;
      var qx = ax + t * dx, qy = ay + t * dy, d = Math.sqrt((x - qx) * (x - qx) + (y - qy) * (y - qy));
      if (!best || d < best.d) best = { d: d, x: qx, y: qy, hdg: deg(Math.atan2(dx, dy)), s: run + t * len };
      run += len;
    }
    return best;
  }

  /** The point s meters along a flat line, with the heading there. */
  function along(p, s) {
    var run = 0;
    for (var k = 0; k + 3 < p.length; k += 2) {
      var dx = p[k + 2] - p[k], dy = p[k + 3] - p[k + 1], len = Math.sqrt(dx * dx + dy * dy);
      if (run + len >= s || k + 4 >= p.length) {
        var t = len > 0 ? Math.max(0, Math.min(1, (s - run) / len)) : 0;
        return { x: p[k] + t * dx, y: p[k + 1] + t * dy, hdg: deg(Math.atan2(dx, dy)) };
      }
      run += len;
    }
    return { x: p[0], y: p[1], hdg: 0 };
  }

  /** The airport's runways in meters: [{id: "01/19", ends: [{id, x, y, hdg}, ...], w}] (cfg.runways: a is ids[0]'s threshold). */
  function runways(cfg, map) {
    var out = [];
    for (var i = 0; i < (cfg.runways || []).length; i++) {
      var r = cfg.runways[i], a = toM(cfg.arp, r.a[0], r.a[1]), b = toM(cfg.arp, r.b[0], r.b[1]);
      var h = deg(Math.atan2(b.x - a.x, b.y - a.y)), id = r.ids.join("/"), w = RWY_W_M;
      var mr = map && map.runways ? map.runways.filter(function (m) { return m.ref === id && !m.c; })[0] : null;
      if (mr && mr.w) w = mr.w;
      out.push({ id: id, w: w, ends: [{ id: r.ids[0], x: a.x, y: a.y, hdg: h }, { id: r.ids[1], x: b.x, y: b.y, hdg: (h + 180) % 360 }] });
    }
    return out;
  }

  /** What a tap at (x, y) meters is on: {type: "rwy", id} | {type: "twy", ref, w, x, y, hdg, i, s} | {type: "closure", index} | null. */
  function hit(cfg, map, st, x, y, scaleM) {
    var pad = Math.max(HIT_PAD_M, scaleM || 0), i;
    for (i = 0; i < st.twys.length; i++) {
      var c = st.twys[i], pts = closurePoints(map, c);
      for (var k = 0; k < pts.length; k++) {
        if (Math.sqrt(Math.pow(pts[k].x - x, 2) + Math.pow(pts[k].y - y, 2)) < c.w / 2 + pad) return { type: "closure", index: i };
      }
    }
    var rs = runways(cfg, map), best = null;
    for (i = 0; i < rs.length; i++) {
      var e = rs[i].ends, n = nearest([e[0].x, e[0].y, e[1].x, e[1].y], x, y);
      if (n && n.d < rs[i].w / 2 + pad && (!best || n.d < best.d)) best = { d: n.d, type: "rwy", id: rs[i].id };
    }
    if (best) return { type: "rwy", id: best.id };
    var tws = (map && map.taxiways) || [], tb = null;
    for (i = 0; i < tws.length; i++) {
      var q = nearest(tws[i].p, x, y);
      if (q && q.d < tws[i].w / 2 + pad && (!tb || q.d < tb.q.d)) tb = { i: i, q: q };
    }
    if (!tb) return null;
    var t = tws[tb.i];
    return { type: "twy", ref: t.ref || "", w: t.w || 23, x: tb.q.x, y: tb.q.y, hdg: tb.q.hdg, i: tb.i, s: tb.q.s };
  }

  /** Points along a closed taxiway stretch, every ~20 m (just its point for a one-spot closure). */
  function closurePoints(map, c) {
    var out = [c.a];
    if (!c.b) return out;
    var tw = map && map.taxiways && c.a.i === c.b.i ? map.taxiways[c.a.i] : null;
    var len = tw ? Math.abs(c.b.s - c.a.s) : Math.sqrt(Math.pow(c.b.x - c.a.x, 2) + Math.pow(c.b.y - c.a.y, 2));
    var n = Math.max(1, Math.round(len / 20));
    for (var k = 1; k < n; k++) {
      var f = k / n;
      out.push(tw ? along(tw.p, c.a.s + (c.b.s - c.a.s) * f) : { x: c.a.x + (c.b.x - c.a.x) * f, y: c.a.y + (c.b.y - c.a.y) * f });
    }
    out.push(c.b);
    return out;
  }

  /** Same numbers every time for the same seed. */
  function rng(seed) {
    var s = 0;
    for (var i = 0; i < String(seed).length; i++) s = (s * 31 + String(seed).charCodeAt(i)) >>> 0;
    s = s || 1;
    return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  }

  /** A row of barricades across a taxiway at point p (taxiway heading p.hdg). */
  function barricades(p, w, out) {
    var n = Math.max(2, Math.ceil((w + 4) / BARRICADE_M)), a = p.hdg * Math.PI / 180;
    var ax = Math.cos(a), ay = -Math.sin(a);     // across the taxiway (90 degrees right of its heading)
    for (var k = 0; k < n; k++) {
      var off = (k - (n - 1) / 2) * (BARRICADE_M + 0.05);
      out.push({ k: KINDS.barricade, x: p.x + ax * off, y: p.y + ay * off, hdg: p.hdg });
    }
  }

  /** The edge rows of a closed stretch: barricades end to end (long side along the taxiway)
   *  on each side, in line with the outer barricades of the end rows, following the taxiway.
   *  Each side is spaced along its own line, so the outside of a bend has no gaps. */
  function sideRows(map, c, out) {
    var n = Math.max(2, Math.ceil((c.w + 4) / BARRICADE_M)), off = (n - 1) / 2 * (BARRICADE_M + 0.05);
    var tw = map && map.taxiways && c.a.i === c.b.i ? map.taxiways[c.a.i] : null;
    var len = tw ? Math.abs(c.b.s - c.a.s) : Math.sqrt(Math.pow(c.b.x - c.a.x, 2) + Math.pow(c.b.y - c.a.y, 2));
    var dir = !tw || c.b.s >= c.a.s ? 1 : -1, straight = deg(Math.atan2(c.b.x - c.a.x, c.b.y - c.a.y));
    function center(d) {
      if (!tw) { var f = d / len; return { x: c.a.x + (c.b.x - c.a.x) * f, y: c.a.y + (c.b.y - c.a.y) * f, hdg: straight }; }
      var q0 = along(tw.p, c.a.s + dir * (d - 1.5)), q1 = along(tw.p, c.a.s + dir * (d + 1.5)), q = along(tw.p, c.a.s + dir * d);
      q.hdg = deg(Math.atan2(q1.x - q0.x, q1.y - q0.y));      // smoothed: a bend in the map line doesn't kink the row
      return q;
    }
    if (len - 1.2 < BARRICADE_M) return;
    for (var side = -1; side <= 1; side += 2) {
      // the side's own line, clear of the end rows, a point every meter
      var line = [], run = [0], d;
      for (d = 0.6; d <= len - 0.6 + 1e-6; d += Math.min(1, len - 0.6 - d) || 1) {
        var q = center(d), a = q.hdg * Math.PI / 180;
        line.push({ x: q.x + Math.cos(a) * off * side, y: q.y - Math.sin(a) * off * side });
        if (line.length > 1) run.push(run[run.length - 1] + Math.hypot(line[line.length - 1].x - line[line.length - 2].x, line[line.length - 1].y - line[line.length - 2].y));
        if (d >= len - 0.6) break;
      }
      var total = run[run.length - 1];
      if (total < BARRICADE_M) continue;
      var m = Math.min(Math.round(total / (BARRICADE_M + 0.05)), SIDE_MAX / 2), step = total / m, j = 0;
      for (var k = 0; k < m; k++) {
        var s0 = step * (k + 0.5);
        while (j < run.length - 2 && run[j + 1] < s0) j++;
        var p0 = line[j], p1 = line[j + 1], t = (s0 - run[j]) / Math.max(1e-9, run[j + 1] - run[j]);
        var lo = line[Math.max(0, j - 1)], hi = line[Math.min(line.length - 1, j + 2)];
        out.push({ k: KINDS.barricade, x: p0.x + (p1.x - p0.x) * t, y: p0.y + (p1.y - p0.y) * t,
          hdg: Math.round(deg(Math.atan2(hi.x - lo.x, hi.y - lo.y)) + 90) % 360 });
      }
    }
  }

  /** Inside a closed stretch, along the edges clear of the vehicles (which keep within w/4 of
   *  the centerline): one dirt or rock pile per 120 m (up to 4) and a porta potty. */
  function props(c, pts, len, out) {
    if (len < 30 || pts.length < 2) return;
    var r = rng(c.id + "props"), np = Math.min(4, 1 + Math.floor(len / 120));
    var n = Math.max(2, Math.ceil((c.w + 4) / BARRICADE_M)), edge = (n - 1) / 2 * (BARRICADE_M + 0.05);
    for (var v = 0; v <= np; v++) {
      var potty = v === np, half = potty ? 0.7 : 2.4;              // footprint half width
      var hi = edge - 0.4 - half, lo = Math.min(hi, c.w / 4 + 1.3 + half);
      var m = Math.min(0.45, (half + 2) / len);                    // clear of the end rows
      var f = m + (1 - 2 * m) * (v + 0.25 + r() * 0.5) / (np + 1), at = f * (pts.length - 1);
      var j = Math.min(pts.length - 2, Math.floor(at)), t = at - j, p = pts[j], q = pts[j + 1];
      var th = Math.atan2(q.x - p.x, q.y - p.y), px = p.x + (q.x - p.x) * t, py = p.y + (q.y - p.y) * t;
      var side = (r() < 0.5 ? -1 : 1) * (lo + r() * (hi - lo));
      out.push({ k: potty ? KINDS.portaPotty : r() < 0.5 ? KINDS.dirtPile : KINDS.rockPile,
        x: px + Math.cos(th) * side, y: py - Math.sin(th) * side,
        hdg: potty ? Math.round(deg(th) + (side > 0 ? 270 : 90)) % 360 : Math.floor(r() * 360) });   // potty door faces in
    }
  }

  /**
   * Everything to put in the sim: [{k, x, y, hdg}] (k = KINDS, meters from the ARP, heading
   * true). Never more than MAX_OBJECTS.
   */
  function objects(cfg, map, st) {
    var out = [], sides = [], i, rs = runways(cfg, map);
    for (i = 0; i < rs.length; i++) {
      if (!st.rwys[rs[i].id]) continue;
      for (var e = 0; e < 2; e++) {
        var end = rs[i].ends[e], h = end.hdg * Math.PI / 180;
        out.push({ k: KINDS.closedX, x: end.x + Math.sin(h) * X_IN_M, y: end.y + Math.cos(h) * X_IN_M, hdg: end.hdg });
      }
    }
    for (i = 0; i < st.twys.length; i++) {
      var c = st.twys[i];
      barricades(c.a, c.w, out);
      if (!c.b) continue;
      barricades(c.b, c.w, out);
      sideRows(map, c, sides);
      var pts = closurePoints(map, c), len = (pts.length - 1) * 20;
      props(c, pts, len, out);
      if (len < 80) continue;
      var r = rng(c.id), nv = Math.min(3, 1 + Math.floor(len / 250));
      for (var v = 0; v < nv; v++) {
        var f = (v + 0.3 + r() * 0.4) / nv, j = Math.min(pts.length - 2, Math.floor(f * (pts.length - 1)));
        var p = pts[j], q = pts[j + 1], th = Math.atan2(q.x - p.x, q.y - p.y), side = (r() - 0.5) * c.w * 0.5;
        out.push({ k: r() < 0.5 ? KINDS.workTruck : KINDS.dumpTruck,
          x: p.x + Math.cos(th) * side, y: p.y - Math.sin(th) * side, hdg: Math.round(deg(th) + (r() - 0.5) * 120 + 360) % 360 });
      }
    }
    return out.concat(sides).slice(0, MAX_OBJECTS);     // too many: the edge rows go first
  }

  /** What the helper gets: {icao, rev, objects: [{k, lat, lon, hdg}]}. */
  function payload(cfg, map, st) {
    var objs = objects(cfg, map, st), list = [];
    for (var i = 0; i < objs.length; i++) {
      var ll = toLatLon(cfg.arp, objs[i].x, objs[i].y);
      list.push({ k: objs[i].k, lat: Math.round(ll.lat * 1e7) / 1e7, lon: Math.round(ll.lon * 1e7) / 1e7, hdg: Math.round(objs[i].hdg) });
    }
    return { icao: cfg.icao, rev: st.rev || 0, objects: list };
  }

  /** Toggles runway id closed / open. */
  function toggleRunway(st, id) {
    if (st.rwys[id]) delete st.rwys[id];
    else st.rwys[id] = 1;
  }

  /** Adds a taxiway closure from tap a to tap b (b near a, or null: one spot). */
  function addTaxiway(st, a, b) {
    if (b && b.type && b.type !== "twy") b = null;
    if (b && Math.sqrt(Math.pow(b.x - a.x, 2) + Math.pow(b.y - a.y, 2)) < SAME_POINT_M) b = null;
    var pt = function (p) { return { x: Math.round(p.x * 10) / 10, y: Math.round(p.y * 10) / 10, hdg: Math.round(p.hdg), i: p.i, s: Math.round(p.s * 10) / 10 }; };
    var c = { id: "T" + Date.now().toString(36) + Math.floor(Math.random() * 1e4), ref: a.ref || (b && b.ref) || "",
      w: Math.max(a.w || 23, (b && b.w) || 0), a: pt(a), b: b ? pt(b) : null };
    st.twys.push(c);
    return c;
  }

  /**
   * The link to the helper: link(getPayload) sends the closures whenever the cab's copy is
   * newer than the helper's (or the helper restarted) and returns status():
   *   {state: "ok" | "off" | "wait", count: objects the helper has in the sim, error}
   */
  function link(getPayload) {
    var st = { state: "wait", count: 0, error: "" }, sentRev = -1, busy = false, stopped = false;
    function req(method, path, body, cb) {
      var x;
      try { x = new XMLHttpRequest(); } catch (e) { cb(e); return; }
      x.open(method, HELPER + path, true);
      if (body) x.setRequestHeader("Content-Type", "application/json");
      x.timeout = 4000;
      x.onload = function () {
        var d = null;
        try { d = JSON.parse(x.responseText); } catch (e) { /* not ours */ }
        cb(x.status === 200 && d ? null : new Error("helper answered " + x.status), d);
      };
      x.onerror = function () { cb(new Error("not running")); };
      x.ontimeout = function () { cb(new Error("no answer")); };
      x.send(body ? JSON.stringify(body) : null);
    }
    function tick() {
      if (stopped || busy) return;
      busy = true;
      req("GET", "/status", null, function (err, d) {
        if (err) { busy = false; st.state = "off"; st.error = err.message; sentRev = -1; return; }
        st.state = "ok"; st.error = d.error || ""; st.count = d.count || 0;
        var p = getPayload();
        if (!p || (d.icao === p.icao && d.rev === p.rev && sentRev === p.rev)) { busy = false; return; }
        req("POST", "/objects", p, function (e2, d2) {
          busy = false;
          if (e2) { st.error = e2.message; return; }
          sentRev = p.rev; st.count = (d2 && d2.count) || st.count; st.error = (d2 && d2.error) || "";
        });
      });
    }
    tick();
    var id = setInterval(tick, 3000);
    return {
      status: function () { return st; },
      kick: function () { sentRev = -1; busy = false; tick(); },
      stop: function () { stopped = true; clearInterval(id); }
    };
  }

  return {
    KINDS: KINDS, HELPER: HELPER, load: load, save: save, empty: empty, toM: toM, toLatLon: toLatLon,
    nearest: nearest, along: along, runways: runways, hit: hit, closurePoints: closurePoints,
    objects: objects, payload: payload, toggleRunway: toggleRunway, addTaxiway: addTaxiway, link: link
  };
})();

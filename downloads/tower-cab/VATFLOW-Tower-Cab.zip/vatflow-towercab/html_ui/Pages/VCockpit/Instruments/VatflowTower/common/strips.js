/*
 * VATFLOW Tower Cab - flight strip bays: the shared model.
 *
 * Three bays (TMU, ground, local by default), each a board three columns wide, split into
 * sections by up to six separator strips; each separator says which column its section
 * sits in (bay.cols, else spread evenly over the columns). A departure strip prints into the "new strips" bay / section when a
 * pilot with a flight plan out of this airport is on the ground here; it drops by itself
 * once airborne (AUTO DROP) or when the controller deletes it. Strips are picked up and
 * put down again, between bays too.
 *
 * Everything lives in the sim's storage per airport, so the three bay screens, their
 * signs and the STRIP BAYS screen share it:
 *   STRIPCFG_<ICAO>   bay names, positions (console face + slide) and separators
 *   STRIPS_<ICAO>     the strips and their order
 * After a change the writer bumps L:VATFLOW_STRIPS_REV; the other screens reload.
 *
 * AUTO SEQ (on by default) keeps each section in taxi order: aircraft that have started
 * taxiing go to the top, nearest their departure runway first (see sequence()).
 */
var VatflowStrips = (function () {
  var MAX_SEPS = 6, BAYS = 3, COLS = 3, NM_PER_DEG = 60;
  var TAXI_KT = 5;            // moving at least this fast once: the aircraft has started taxiing
  var PASS_NM = 0.03;         // a strip passes the one above only when it is ~50 m closer to the runway
  var RWY_USE_MS = 30 * 60000;  // runway ends departures used in the last 30 minutes are "in use"
  // console faces (45 degrees apart, counter-clockwise from the front; 4 = stairs, no console)
  var FACES = [0, 1, 2, 3, 5, 6, 7];
  var FACE_NAMES = { 0: "FRONT", 1: "FRONT-LEFT", 2: "LEFT", 3: "BACK-LEFT", 5: "BACK-RIGHT", 6: "RIGHT", 7: "FRONT-RIGHT" };
  var SLIDE_MAX = 1.2;
  var SLIDE_REST = 0.8;   // the bay model is built (and rests) 0.8 m right of the face centre

  function defaults() {
    return {
      bays: [
        { name: "TMU", face: 2, slide: -0.6, seps: ["PROPOSED", "RELEASED", "DELAYED"] },
        { name: "GROUND", face: 7, slide: 0.3, seps: ["PROPOSED", "CLEARED", "TAXI"] },
        { name: "LOCAL", face: 0, slide: 0.8, seps: ["HOLD SHORT", "RUNWAY", "DEPARTED"] }
      ],
      newBay: 1, newSec: 0, autoDrop: true, autoSeq: true
    };
  }
  // where the one-column bays stood by default (a saved layout still there moves to the new spot)
  var OLD_POSE = [[3, 0.4], [7, -0.5], [0, 0.55]];

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  function config(icao) {
    var c = VatflowStore.get("STRIPCFG_" + icao, null);
    if (!(c && c.bays && c.bays.length === BAYS)) return defaults();
    var d = defaults();
    for (var b = 0; b < BAYS; b++) {
      if (c.bays[b].face === OLD_POSE[b][0] && c.bays[b].slide === OLD_POSE[b][1]) {
        c.bays[b].face = d.bays[b].face;
        c.bays[b].slide = d.bays[b].slide;
      }
    }
    return c;
  }

  /** Column (0..2) of each separator's section: the bay's own choice, else spread evenly. */
  function cols(bay) {
    var n = bay.seps.length, out = [];
    for (var i = 0; i < n; i++) {
      var c = bay.cols && bay.cols[i];
      out.push(c >= 0 && c < COLS ? c : Math.floor(i * COLS / n));
    }
    return out;
  }

  /** Column for a new separator: the one with the fewest (the rightmost of those). */
  function freeCol(bay) {
    var cs = cols(bay), count = [0, 0, 0], best = COLS - 1;
    cs.forEach(function (c) { count[c]++; });
    for (var c = COLS - 1; c >= 0; c--) if (count[c] < count[best]) best = c;
    return best;
  }

  function emptyState() { return { strips: {}, bays: [[[]], [[]], [[]]], held: null, dismissed: {}, rwyUse: {} }; }

  function state(icao) {
    var s = VatflowStore.get("STRIPS_" + icao, null);
    return s && s.bays ? s : emptyState();
  }

  /** Sections per bay = its separators (one unnamed section when it has none). */
  function normalize(st, cfg) {
    for (var b = 0; b < BAYS; b++) {
      var want = Math.max(1, cfg.bays[b].seps.length), secs = st.bays[b] || [[]];
      while (secs.length < want) secs.push([]);
      while (secs.length > want) { var extra = secs.pop(); secs[secs.length - 1] = secs[secs.length - 1].concat(extra); }
      // drop ids that lost their strip, and duplicates
      var seen = {};
      for (var s = 0; s < secs.length; s++) {
        secs[s] = secs[s].filter(function (id) { if (!st.strips[id] || seen[id]) return false; seen[id] = true; return true; });
      }
      st.bays[b] = secs;
    }
    if (st.held && !st.strips[st.held]) st.held = null;
    return st;
  }

  function rev() {
    if (typeof SimVar === "undefined") return VatflowStore.get("STRIPS_REV", 0);
    return SimVar.GetSimVarValue("L:VATFLOW_STRIPS_REV", "number") || 0;
  }

  function bump() {
    var r = (rev() + 1) % 1000000;
    if (typeof SimVar === "undefined") VatflowStore.set("STRIPS_REV", r);
    else SimVar.SetSimVarValue("L:VATFLOW_STRIPS_REV", "number", r);
    return r;
  }

  function saveConfig(icao, cfg) { VatflowStore.set("STRIPCFG_" + icao, cfg); bump(); }

  /** Read, change, write, in one go (fn(state, cfg) returns false to leave it untouched). */
  function update(icao, fn) {
    var cfg = config(icao), st = normalize(state(icao), cfg);
    if (fn(st, cfg) === false) return st;
    normalize(st, cfg);
    VatflowStore.set("STRIPS_" + icao, st);
    bump();
    return st;
  }

  // ---- strip contents (FAA terminal departure strip) -------------------------------

  function lidOf(icao) { return /^K[A-Z0-9]{3}$/.test(icao || "") ? icao.slice(1) : (icao || ""); }

  /** Requested altitude box: hundreds of feet, VFR plans "VFR" or "VFR/055". */
  function altBox(fp) {
    var a = String(fp.altitude || "").toUpperCase().replace(/^FL/, ""), vfr = fp.flight_rules === "V";
    var n = parseInt(a, 10);
    if (!isNaN(n) && n > 0) {
      var h = n >= 1000 ? Math.round(n / 100) : n;
      var s = (h < 100 ? "0" : "") + (h < 10 ? "0" : "") + h;
      return vfr ? "VFR/" + s : s;
    }
    return vfr ? "VFR" : "";
  }

  function fromPilot(p, now) {
    var fp = p.flight_plan || {};
    var bcn = String(fp.assigned_transponder || "");
    return {
      id: p.callsign, cs: p.callsign,
      type: String(fp.aircraft_faa || fp.aircraft_short || fp.aircraft || "").toUpperCase(),
      cid: String(p.cid || "").slice(-3), rev: fp.revision_id || 0,
      bcn: /^0+$/.test(bcn) ? "" : bcn,
      ptime: fp.deptime ? "P" + String(fp.deptime).slice(0, 4) : "",
      alt: altBox(fp), vfr: fp.flight_rules === "V",
      dep: lidOf(fp.departure), dest: lidOf(fp.arrival),
      route: String(fp.route || "").replace(/\s+/g, " ").trim().toUpperCase(),
      rmk: remarks(fp.remarks),
      seen: now
    };
  }

  /** Remarks box: the free-text part (after RMK/) and a text-only / receive-only voice flag. */
  function remarks(r) {
    r = String(r || "").toUpperCase();
    var voice = /\/T\//.test(r) ? "/T/ " : /\/R\//.test(r) ? "/R/ " : "";
    var m = /(?:^|\s)RMK\/(.*)$/.exec(r), text = m ? m[1] : (/^[A-Z]+\/\S/.test(r) ? "" : r);
    text = text.replace(/\/[VTR]\//g, " ").replace(/\bSIMBRIEF\b/g, " ").replace(/\s+/g, " ").trim();
    return (voice + text).trim();
  }

  var SID_RE = /^[A-Z]{3,6}\d[A-Z]?$/, FIX_RE = /^[A-Z]{2,5}$/, LATLON_RE = /^\d{2,4}[NS]\d{3,5}[EW]$/;
  var SPEED_RE = /^[NMK]\d{3,4}(?:[FAMS]\d{3,4})?$/;

  /**
   * Route box: the SID and the first fix after it ("JDUBB1 JDUBB", "RNLDI4.RNLDI" too), or
   * only the first fix when no SID is filed. Skips speed / level groups, DCT, the departure
   * airport and "/..." suffixes. -> {text, more}: more = the filed route goes on after them.
   * A route that starts with neither (an airway, free text) shows its first word.
   */
  function sidFix(route, dep, dest) {
    var toks = String(route || "").toUpperCase().split(/\s+/).filter(function (t) { return t; });
    dep = String(dep || "").toUpperCase(); dest = String(dest || "").toUpperCase();
    function skip(t) { return !t || t === "DCT" || t === "SID" || SPEED_RE.test(t) || t === dep || t === "K" + dep; }
    function isFix(t) { return (FIX_RE.test(t) || LATLON_RE.test(t)) && t !== "DCT"; }
    var sid = "", fix = "", i = 0;
    for (; i < toks.length; i++) {
      var t = toks[i].split("/")[0];
      if (skip(t)) continue;
      var dot = t.split(".");
      if (!sid && SID_RE.test(dot[0])) {
        sid = dot[0];
        if (dot[1] && isFix(dot[1])) { fix = dot[1]; i++; break; }
        continue;
      }
      if (isFix(t)) { fix = t; i++; }
      break;
    }
    var parts = [sid, fix].filter(function (x) { return x; });
    if (!parts.length && i < toks.length) { parts = [toks[i].split("/")[0]]; i++; }
    var more = toks.slice(i).some(function (t) {
      t = t.split("/")[0];
      return !skip(t) && t !== dest && t !== "K" + dest;
    });
    return { text: parts.join(" "), more: more };
  }

  /** "1432" for a release time (ms). */
  function hhmm(ms) {
    var d = new Date(ms), h = d.getUTCHours(), m = d.getUTCMinutes();
    return (h < 10 ? "0" : "") + h + (m < 10 ? "0" : "") + m;
  }

  /**
   * Release times by callsign from the VATFLOW TMU programs (hub EDCTs: {cs, t}) and the FCA
   * programs (fca.releases[cs].edctMs), -> {CS: {t, src: "EDCT" | "REL"}}. A flight with both
   * shows the later one (that is the one it has to wait for).
   */
  function releases(edcts, fcas) {
    var out = {};
    function add(cs, t, src) {
      if (!cs || !(+t > 0)) return;
      if (!out[cs] || +t > out[cs].t) out[cs] = { t: +t, src: src };
    }
    for (var k in edcts || {}) { var e = edcts[k]; if (e) add(e.cs, e.t, "EDCT"); }
    (fcas || []).forEach(function (f) {
      if (!f || f.enabled === false || !f.releases || typeof f.releases !== "object") return;
      for (var cs in f.releases) { var r = f.releases[cs]; if (r) add(cs, r.edctMs, "REL"); }
    });
    return out;
  }

  function distNm(a, lat, lon) {
    var x = (lon - a.lon) * NM_PER_DEG * Math.cos(a.lat * Math.PI / 180), y = (lat - a.lat) * NM_PER_DEG;
    return Math.sqrt(x * x + y * y);
  }

  // ---- taxi order (AUTO SEQ) ------------------------------------------------------------

  function xy(a, lat, lon) {
    return [(lon - a.lon) * NM_PER_DEG * Math.cos(a.lat * Math.PI / 180), (lat - a.lat) * NM_PER_DEG];
  }

  /** Both ends of each runway ({ids, a: [lat, lon] (ids[0]'s threshold), b}): {id, lat, lon, hdg (true), lenNm}. */
  function runwayEnds(runways) {
    var out = [];
    (runways || []).forEach(function (r) {
      if (!r || !r.ids || !r.a || !r.b) return;
      var A = { lat: r.a[0], lon: r.a[1] }, v = xy(A, r.b[0], r.b[1]);
      var hdg = (Math.atan2(v[0], v[1]) * 180 / Math.PI + 360) % 360, len = Math.sqrt(v[0] * v[0] + v[1] * v[1]);
      out.push({ id: r.ids[0], lat: r.a[0], lon: r.a[1], hdg: hdg, lenNm: len });
      out.push({ id: r.ids[1], lat: r.b[0], lon: r.b[1], hdg: (hdg + 180) % 360, lenNm: len });
    });
    return out;
  }

  function hdgOff(a, b) { var d = Math.abs(((a - b) % 360 + 360) % 360); return d > 180 ? 360 - d : d; }

  /** The runway end a departure is rolling on / just lifted off from (aligned, on the centreline), or null. */
  function takeoffEnd(ends, p, agl) {
    if ((p.groundspeed || 0) < 40 || agl > 2000) return null;
    for (var i = 0; i < ends.length; i++) {
      var e = ends[i];
      if (hdgOff(p.heading || 0, e.hdg) > 20) continue;
      var v = xy(e, p.latitude, p.longitude), h = e.hdg * Math.PI / 180;
      var along = v[0] * Math.sin(h) + v[1] * Math.cos(h), across = Math.abs(v[0] * Math.cos(h) - v[1] * Math.sin(h));
      if (across < 0.25 && along > -0.1 && along < e.lenNm + 3) return e;
    }
    return null;
  }

  /**
   * The runway ends departures go to: the ones departures took off from in the last 30
   * minutes (st.rwyUse), else the ones most into the wind (5 kt or more), else all of them.
   */
  function depEnds(st, ends, wind, now) {
    var use = st.rwyUse || {};
    var used = ends.filter(function (e) { return use[e.id] && now - use[e.id] < RWY_USE_MS; });
    if (used.length) return used;
    var dir = wind && parseInt(wind.dir, 10);
    if (wind && wind.kt >= 5 && !isNaN(dir)) {
      var score = function (e) { return Math.cos((dir - e.hdg) * Math.PI / 180); }, best = -2;
      ends.forEach(function (e) { best = Math.max(best, score(e)); });
      var into = ends.filter(function (e) { return score(e) > 0 && score(e) >= best - 0.03; });
      if (into.length) return into;
    }
    return ends;
  }

  /**
   * AUTO SEQ: in every section, the strips of aircraft that have started taxiing (strip.taxi)
   * go to the top, nearest the departure runway first (straight-line distance to the
   * threshold); strips of parked aircraft keep their order below them. A strip passes the
   * one above it only when it is more than ~50 m closer, so two aircraft side by side at the
   * hold short line don't keep swapping. Returns true when an order changed.
   */
  function sequence(st, pilots, ends) {
    if (!ends || !ends.length) return false;
    var dist = {}, changed = false;
    (pilots || []).forEach(function (p) {
      var s = st.strips[p.callsign];
      if (!s || !s.taxi) return;
      var best = Infinity;
      ends.forEach(function (e) { best = Math.min(best, distNm(e, p.latitude, p.longitude)); });
      dist[p.callsign] = best;
    });
    for (var b = 0; b < st.bays.length; b++) {
      for (var k = 0; k < st.bays[b].length; k++) {
        var list = st.bays[b][k];
        var taxi = list.filter(function (id) { return dist[id] != null; });
        var parked = list.filter(function (id) { return dist[id] == null; });
        for (var i = 1; i < taxi.length; i++) {
          for (var j = i; j > 0 && dist[taxi[j]] < dist[taxi[j - 1]] - PASS_NM; j--) {
            var t = taxi[j]; taxi[j] = taxi[j - 1]; taxi[j - 1] = t;
          }
        }
        var out = taxi.concat(parked);
        if (out.join(" ") !== list.join(" ")) { st.bays[b][k] = out; changed = true; }
      }
    }
    return changed;
  }

  /**
   * Feed -> strips. site: {icao, arp, elevFt, runways?, wind?, releases?}. New departures on
   * the ground here print into the "new strips" bay / section; airborne or long-gone ones
   * drop (AUTO DROP). site.releases ({CS: {t, src}}, see releases()) sets each strip's
   * release time box; without it they stay as they are. With AUTO SEQ and site.runways the
   * sections are kept in taxi order (sequence()). Returns true when something changed.
   */
  function ingest(st, cfg, pilots, site, now) {
    var changed = false, here = {}, rels = site.releases, ends = runwayEnds(site.runways);
    if (!st.rwyUse) st.rwyUse = {};
    for (var i = 0; i < (pilots || []).length; i++) {
      var p = pilots[i], fp = p.flight_plan;
      if (!fp || String(fp.departure || "").toUpperCase() !== site.icao) continue;
      var d = distNm(site.arp, p.latitude, p.longitude), agl = (p.altitude || 0) - (site.elevFt || 0);
      var onGround = d < 5 && agl < 300 && (p.groundspeed || 0) < 60;
      var airborne = agl > 800 || d > 6;
      var cur = st.strips[p.callsign];
      here[p.callsign] = true;
      if (cur) {
        var off = takeoffEnd(ends, p, agl);
        if (off) st.rwyUse[off.id] = now;          // learn the departure runway in use
        var fresh = fromPilot(p, now);
        if (airborne && cfg.autoDrop) { remove(st, p.callsign, false); changed = true; continue; }
        fresh.cocked = cur.cocked;
        fresh.printed = cur.printed;
        fresh.amended = cur.amended || fresh.rev !== cur.rev;
        fresh.taxi = cur.taxi || (onGround && (p.groundspeed || 0) >= TAXI_KT);
        fresh.rel = rels ? releaseOf(rels, p.callsign) : (cur.rel || null);
        if (JSON.stringify(cleanForCompare(fresh)) !== JSON.stringify(cleanForCompare(cur))) changed = true;
        st.strips[p.callsign] = fresh;
        continue;
      }
      if (!onGround) continue;
      var rv = fp.revision_id || 0;
      if (st.dismissed[p.callsign] === rv) continue;           // deleted by the controller (this revision)
      var s = fromPilot(p, now);
      s.printed = now;
      s.taxi = (p.groundspeed || 0) >= TAXI_KT;
      s.rel = rels ? releaseOf(rels, p.callsign) : null;
      st.strips[p.callsign] = s;
      var b = Math.min(BAYS - 1, Math.max(0, cfg.newBay)), sec = st.bays[b] || (st.bays[b] = [[]]);
      var k = Math.min(sec.length - 1, Math.max(0, cfg.newSec));
      sec[k].push(p.callsign);
      changed = true;
    }
    // gone from the network: drop after 3 minutes
    for (var cs in st.strips) {
      if (!here[cs] && cfg.autoDrop && now - (st.strips[cs].seen || 0) > 180000) { remove(st, cs, false); changed = true; }
    }
    if (cfg.autoSeq !== false && sequence(st, pilots, depEnds(st, ends, site.wind, now))) changed = true;
    return changed;
  }

  function releaseOf(rels, cs) { var r = rels[cs]; return r ? { t: r.t, src: r.src } : null; }

  function cleanForCompare(s) { var c = clone(s); delete c.seen; return c; }

  function where(st, id) {
    for (var b = 0; b < st.bays.length; b++) {
      for (var s = 0; s < st.bays[b].length; s++) {
        var i = st.bays[b][s].indexOf(id);
        if (i >= 0) return { bay: b, sec: s, idx: i };
      }
    }
    return null;
  }

  function take(st, id) {
    var w = where(st, id);
    if (w) st.bays[w.bay][w.sec].splice(w.idx, 1);
    return w;
  }

  /** Deleted by the controller (dismiss: it doesn't print again until its plan is amended). */
  function remove(st, id, dismiss) {
    take(st, id);
    if (dismiss && st.strips[id]) st.dismissed[id] = st.strips[id].rev;
    delete st.strips[id];
    if (st.held === id) st.held = null;
  }

  /** Puts strip id at bay b, section sec, before position idx (-1 = at the end). */
  function place(st, id, b, sec, idx) {
    var from = take(st, id);
    var list = st.bays[b][sec];
    if (from && from.bay === b && from.sec === sec && idx > from.idx) idx--;   // its own slot moved up
    if (idx < 0 || idx > list.length) idx = list.length;
    list.splice(idx, 0, id);
  }

  function cock(st, id) { if (st.strips[id]) st.strips[id].cocked = !st.strips[id].cocked; }

  /** L: var values that put bay n (0..2) where its config says. */
  function poseVars(bayCfg) {
    var slide = Math.max(-SLIDE_MAX, Math.min(SLIDE_MAX, bayCfg.slide || 0));
    return { deg: (45 * (bayCfg.face || 0)) % 360, slide: Math.round(200 + (slide - SLIDE_REST) * 100) };
  }

  function applyPose(n, bayCfg) {
    if (typeof SimVar === "undefined") return;
    var v = poseVars(bayCfg);
    SimVar.SetSimVarValue("L:VATFLOW_BAY_" + (n + 1) + "_DEG", "number", v.deg);
    SimVar.SetSimVarValue("L:VATFLOW_BAY_" + (n + 1) + "_SLIDE", "number", v.slide);
  }

  return {
    MAX_SEPS: MAX_SEPS, BAYS: BAYS, COLS: COLS, cols: cols, freeCol: freeCol, FACES: FACES, FACE_NAMES: FACE_NAMES, SLIDE_MAX: SLIDE_MAX,
    defaults: defaults, config: config, saveConfig: saveConfig, state: state, emptyState: emptyState,
    normalize: normalize, update: update, rev: rev, bump: bump, ingest: ingest, fromPilot: fromPilot, altBox: altBox,
    remarks: remarks, sidFix: sidFix, hhmm: hhmm, releases: releases, runwayEnds: runwayEnds, depEnds: depEnds,
    sequence: sequence, where: where, place: place, remove: remove, cock: cock, poseVars: poseVars, applyPose: applyPose
  };
})();

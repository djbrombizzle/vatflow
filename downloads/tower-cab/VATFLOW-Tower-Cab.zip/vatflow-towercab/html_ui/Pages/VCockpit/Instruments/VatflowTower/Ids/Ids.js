/*
 * VATFLOW Tower Cab - IDS (an app on any screen's MENU): the tower information display page.
 *
 *   RUNWAYS        departure and arrival runway ends in use (from the VATSIM ATIS, else what
 *                  the traffic used in the last 30 minutes, else into the wind) with each one's
 *                  head / tail and crosswind from the METAR
 *   TAXI OUT       the average taxi-out time over the last hour (first move to the takeoff roll,
 *                  timed by the cab like the VATFLOW Taxi Monitor), its trend, who is taxiing now
 *   FLOW           this airport's VATFLOW Airport TMU program (AAR, MIT / minutes in trail), a
 *                  ground stop, the strips with release times (EDCT / REL) and the VATFLOW
 *                  restrictions that name the airport (the VATFLOW hub, read only)
 *   ATIS           the VATSIM ATIS split into its parts, every NOTAM / advisory highlighted in its
 *                  category's colour (VATFLOW's D-ATIS parser, common/vatflow-datis.js)
 *   REAL NOTAMS    the real-world FAA D-ATIS for the airport (atis.info, else datis.clowd.io,
 *                  direct or through a CORS proxy) with its NOTAMs picked out the same way
 *   TAF            the airport's TAF (NWS API, else aviationweather.gov, else the NWS text server)
 *
 * The runways, taxi times and ATIS come from the strip bay feed (TWROPS_<ICAO>, common/twr-ops.js).
 */
var IdsView = (function () {
  var DATIS_MS = 10 * 60000, TAF_MS = 20 * 60000;
  var DATIS_SRC = ["https://atis.info/api/", "https://datis.clowd.io/api/"];
  var PROXY = [function (u) { return u; }, function (u) { return "https://api.allorigins.win/raw?url=" + encodeURIComponent(u); }];
  var CAT_COLOR = {
    "rwy-closed": "#ff5a4a", "twy-closed": "#ff9a4a", closed: "#ff9a4a", "wx-hazard": "#ff5ad2", "rwy-cond": "#5ad2ff",
    obstruction: "#ffd24a", navaid: "#c79bff", construction: "#ffb347", wildlife: "#9be37a", procedure: "#7fc8ff", general: "#d7dde4"
  };

  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

  function IdsView(el, cfg) {
    this.el = el;
    this.cfg = cfg;
    this.metar = null;
    this.datis = null;          // [{type, datis, time}] or null
    this.datisErr = "";
    this.taf = null;
    this.hub = null;
    this.cache = {};
    el.innerHTML = '<div class="is-root"><div class="is-top"><span class="is-title">IDS</span><span class="is-icao"></span>' +
      '<span class="is-atis"></span><span class="is-wx"></span><span class="is-zulu"></span></div><div class="is-body">' +
      '<div class="is-left"><div class="is-box"><div class="is-h">RUNWAYS</div><div class="is-rwy"></div></div>' +
      '<div class="is-box"><div class="is-h">TAXI OUT</div><div class="is-taxi"></div></div>' +
      '<div class="is-box is-grow"><div class="is-h">FLOW / TMI (VATFLOW)</div><div class="is-tmi"></div></div></div>' +
      '<div class="is-right"><div class="is-box is-atisbox"><div class="is-h">VATSIM ATIS</div><div class="is-atxt"></div></div>' +
      '<div class="is-box is-notbox"><div class="is-h">REAL-WORLD NOTAMS (FAA D-ATIS)</div><div class="is-not"></div></div>' +
      '<div class="is-box is-tafbox"><div class="is-h">TAF</div><div class="is-taf"></div></div></div></div></div>';
    var q = function (c) { return el.querySelector(c); };
    this.f = { icao: q(".is-icao"), atis: q(".is-atis"), wx: q(".is-wx"), zulu: q(".is-zulu"), rwy: q(".is-rwy"), taxi: q(".is-taxi"),
      tmi: q(".is-tmi"), atxt: q(".is-atxt"), not: q(".is-not"), taf: q(".is-taf") };
  }

  IdsView.CAT_COLOR = CAT_COLOR;

  IdsView.prototype.start = function () {
    var self = this, icao = this.cfg.icao;
    VatflowFeed.pollMetars([icao], function (m) { self.metar = m[icao] || null; });
    if (typeof VatflowHub !== "undefined") VatflowHub.listen(function (h) { self.hub = h; });
    (function datis() { self.fetchDatis(); setTimeout(datis, DATIS_MS); })();
    (function taf() { self.fetchTaf(); setTimeout(taf, TAF_MS); })();
  };

  /** The real D-ATIS: each source direct, then through a CORS proxy; the first with text wins. */
  IdsView.prototype.fetchDatis = function () {
    var self = this, icao = this.cfg.icao, tries = [];
    DATIS_SRC.forEach(function (s) { PROXY.forEach(function (p) { tries.push(p(s + icao)); }); });
    (function next(i) {
      if (i >= tries.length) { self.datisErr = self.datis ? "" : "NO FAA D-ATIS FOR " + icao; return; }
      VatflowFeed.httpGet(tries[i], function (err, text) {
        var list = null;
        if (!err) { try { list = VatflowDatis.normalizeDatis(JSON.parse(text)); } catch (e) { list = null; } }
        if (list && list.length) { self.datis = list; self.datisErr = ""; return; }
        next(i + 1);
      });
    })(0);
  };

  IdsView.prototype.fetchTaf = function () {
    var self = this, icao = this.cfg.icao, lid = /^K[A-Z0-9]{3}$/.test(icao) ? icao.slice(1) : icao;
    function got(t) { self.taf = t; self.tafAt = Date.now(); }
    function others() {
      VatflowFeed.httpGet("https://aviationweather.gov/api/data/taf?format=raw&ids=" + icao, function (err, text) {
        if (!err && text && text.indexOf(icao) >= 0) { got(String(text).trim()); return; }
        VatflowFeed.httpGet("https://tgftp.nws.noaa.gov/data/forecasts/taf/stations/" + icao + ".TXT", function (e, t) {
          if (!e && t && t.indexOf(icao) >= 0) got(String(t).replace(/^\d{4}\/\d{2}\/\d{2} \d{2}:\d{2}\s*/, "").trim());
        });
      });
    }
    var x = new XMLHttpRequest();
    x.open("GET", "https://api.weather.gov/products/types/TAF/locations/" + lid, true);
    x.timeout = 10000;
    x.setRequestHeader("Accept", "application/ld+json");
    x.onreadystatechange = function () {
      if (x.readyState !== 4) return;
      var first = null;
      try { var j = JSON.parse(x.responseText); first = j && j["@graph"] && j["@graph"][0]; } catch (e) { first = null; }
      if (x.status !== 200 || !first || !first["@id"]) { others(); return; }
      var y = new XMLHttpRequest();
      y.open("GET", first["@id"], true);
      y.timeout = 10000;
      y.setRequestHeader("Accept", "application/ld+json");
      y.onreadystatechange = function () {
        if (y.readyState !== 4) return;
        var t = null;
        try { t = IdsView.tafFromProduct(JSON.parse(y.responseText).productText, icao); } catch (e) { t = null; }
        if (t) got(t); else others();
      };
      y.send();
    };
    x.send();
  };

  /** The airport's TAF out of an NWS text product, up to the "=" or a blank line. */
  IdsView.tafFromProduct = function (text, icao) {
    var lines = String(text || "").split(/\r?\n/), out = [], on = false, re = new RegExp("^(TAF\\s+(AMD\\s+|COR\\s+)?)?" + icao + "\\s+\\d{6}Z");
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i].trim();
      if (!on) { if (re.test(l)) on = true; else continue; }
      if (!l || l === "$$") break;
      out.push(l);
      if (/=$/.test(l)) break;
    }
    return out.length ? out.join(" ").replace(/=$/, "").trim() : null;
  };

  /** ATIS text -> HTML, its NOTAMs in their category colours (runway use in white, weather dimmed). */
  IdsView.atisHtml = function (text) {
    if (!text) return "";
    var segs = VatflowDatis.parseAtis(text), h = "";
    segs.forEach(function (s) {
      if (s.kind === "notam") {
        h += '<span class="is-notam" style="color:' + (CAT_COLOR[s.category] || CAT_COLOR.general) + '"><span class="is-cat">' +
          esc(s.categoryLabel) + "</span> " + esc(s.text) + "</span> ";
      } else h += '<span class="is-' + s.kind + '">' + esc(s.text) + "</span> ";
    });
    return h;
  };

  /** The NOTAMs alone (real-world D-ATIS), one per line. */
  IdsView.notamHtml = function (list) {
    var h = "", seen = {};
    (list || []).forEach(function (d) {
      VatflowDatis.parseAtis(d.datis).forEach(function (s) {
        if (s.kind !== "notam" || seen[s.text]) return;
        seen[s.text] = true;
        h += '<div class="is-nl" style="color:' + (CAT_COLOR[s.category] || CAT_COLOR.general) + '"><span class="is-cat">' + esc(s.categoryLabel) +
          "</span> " + esc(s.text) + "</div>";
      });
    });
    return h;
  };

  /** Restrictions (hub, object or list) that name the airport: [{restriction, requesting, providing, start, stop}]. */
  IdsView.restrictionsFor = function (restr, icao, lid) {
    var list = Array.isArray(restr) ? restr : Object.keys(restr || {}).map(function (k) { return restr[k]; });
    var re = new RegExp("\\b(" + icao + (lid ? "|" + lid : "") + ")\\b");
    return list.filter(function (x) {
      return x && re.test(String(x.restriction || "").toUpperCase() + " " + String(x.requesting || "").toUpperCase() + " " + String(x.providing || "").toUpperCase());
    });
  };

  IdsView.prototype.set = function (k, html) {
    if (this.cache[k] === html) return;
    this.cache[k] = html;
    this.f[k].innerHTML = html;
  };

  IdsView.prototype.render = function () {
    var cfg = this.cfg, icao = cfg.icao, now = Date.now(), O = VatflowOps, f = this.f, mm = VatflowDepSeq.mmss;
    var ops = VatflowStore.get("TWROPS_" + icao, null), es = O.ends(cfg.runways);
    var wind = this.metar && this.metar.wind ? this.metar.wind : ops && ops.wind;
    f.icao.textContent = icao;
    f.atis.textContent = ops && ops.atis && ops.atis.code ? "ATIS " + ops.atis.code : "NO VATSIM ATIS";
    f.wx.textContent = (wind ? "WIND " + wind.dir + "/" + wind.kt + (wind.gust ? "G" + wind.gust : "") : "") + (this.metar && this.metar.altim ? "  A" + this.metar.altim.replace(".", "") : "");
    var z = VatflowDraw.zulu(VatflowDraw.zuluNow());
    f.zulu.textContent = z.hh + z.mm + ":" + z.ss + "Z";
    // runways
    var h = "";
    if (!ops) h = '<div class="is-dim">WAITING FOR THE STRIP BAYS\' FEED</div>';
    else {
      [["DEP", ops.dep], ["ARR", ops.arr]].forEach(function (k) {
        var u = k[1] || { ids: [], src: "" };
        h += '<div class="is-rl"><span class="is-rk">' + k[0] + '</span><span class="is-rids">' + esc(u.ids.join(" ")) + '</span><span class="is-src">' +
          esc(u.src || "ALL") + "</span></div>";
      });
      var shown = {};
      (ops.dep ? ops.dep.ids : []).concat(ops.arr ? ops.arr.ids : []).forEach(function (id) {
        if (shown[id]) return;
        shown[id] = true;
        var e = es.filter(function (x) { return x.id === id; })[0], c = e && O.components(e, wind);
        if (!c) return;
        h += '<div class="is-wc"><span class="is-wid">' + esc(id) + '</span><span class="' + (c.head < 0 ? "is-bad" : "") + '">' +
          (c.head < 0 ? "TAIL " + -c.head : "HEAD " + c.head) + '</span><span class="' + (Math.abs(c.cross) >= 15 ? "is-bad" : "") + '">X ' +
          Math.abs(c.cross) + (c.cross ? (c.cross > 0 ? "R" : "L") : "") + (c.gustCross ? " G" + Math.abs(c.gustCross) : "") + "</span></div>";
      });
    }
    this.set("rwy", h);
    // taxi out
    var tx = ops && ops.taxi;
    h = !tx ? "" : (tx.avg ? '<div class="is-big">' + mm(tx.avg) + '<span class="is-sm"> AVG LAST HOUR (' + tx.n + ")" +
      (tx.trend ? " " + (tx.trend === "UP" ? "RISING" : "FALLING") + " FROM " + mm(tx.prev) : "") + "</span></div>"
      : '<div class="is-dim">NO TAKEOFFS TIMED IN THE LAST HOUR</div>') +
      '<div class="is-sm">' + (tx.taxiing.length ? tx.taxiing.length + " TAXIING NOW: " + tx.taxiing.slice(0, 4).map(function (x) {
        return esc(x.cs) + " " + mm(x.sec); }).join("  ") : "NOBODY TAXIING OUT") + "</div>";
    this.set("taxi", h);
    // flow programs
    h = "";
    var hub = this.hub, lid = cfg.lid || "";
    if (hub) {
      var r = hub.rates && (hub.rates[icao] || hub.rates[lid]);
      if (r) h += '<div class="is-tl">PROGRAM <b>AAR ' + esc(r.aar) + "</b>" + (+r.mit ? " MIT " + esc(r.mit) : +r.trail ? " TRAIL " + esc(r.trail) + " MIN" : "") +
        (r.gates && r.gates.length ? " - " + r.gates.slice(0, 4).map(function (g) { return esc(g.name) + (g.mit ? " " + g.mit + "MIT" : g.trail ? " " + g.trail + "MIN" : ""); }).join(", ") : "") + "</div>";
      var gs = typeof VatflowAptFlow !== "undefined" ? VatflowAptFlow.groundStopFor(hub.groundStops, icao) : null;
      if (gs) h += '<div class="is-tl is-bad">GROUND STOP UNTIL ' + esc(gs) + "</div>";
      IdsView.restrictionsFor(hub.restrictions, icao, lid).slice(0, 5).forEach(function (x) {
        h += '<div class="is-tl is-restr">' + esc(x.restriction) + (x.requesting || x.providing ? " <span class=\"is-dim\">" + esc(x.requesting || "") + "/" + esc(x.providing || "") + "</span>" : "") +
          (x.start || x.stop ? " " + esc(x.start || "") + "-" + esc(x.stop || "") : "") + "</div>";
      });
    }
    var st = VatflowStore.get("STRIPS_" + icao, null), rels = [];
    if (st && st.strips) for (var cs in st.strips) { var s = st.strips[cs]; if (s && s.rel && s.rel.t) rels.push({ cs: cs, t: s.rel.t, src: s.rel.src }); }
    rels.sort(function (a, b) { return a.t - b.t; });
    if (rels.length) h += '<div class="is-tl">RELEASE TIMES: ' + rels.slice(0, 5).map(function (x) { return esc(x.cs) + " " + x.src + " " + VatflowStrips.hhmm(x.t); }).join("  ") + "</div>";
    if (!h) h = '<div class="is-dim">' + (hub ? "NO VATFLOW PROGRAM, GROUND STOP, RELEASE OR RESTRICTION FOR " + esc(icao) : "CONNECTING TO THE VATFLOW HUB...") + "</div>";
    this.set("tmi", h);
    // ATIS, real NOTAMs, TAF
    this.set("atxt", ops && ops.atis && ops.atis.text ? IdsView.atisHtml(ops.atis.text) : '<div class="is-dim">NO VATSIM ATIS ONLINE FOR ' + esc(icao) + "</div>");
    var nh = this.datis ? IdsView.notamHtml(this.datis) : "";
    this.set("not", nh || '<div class="is-dim">' + esc(this.datis ? "NO NOTAMS IN THE FAA D-ATIS" : this.datisErr || "LOADING FAA D-ATIS...") + "</div>");
    var t = this.taf ? esc(this.taf.replace(/\s+/g, " ").replace(/^TAF (AMD |COR )?/, "")).split(/ (?=FM\d{6}|TEMPO |BECMG |PROB\d{2} )/)
      .map(function (p) { return '<div class="is-tafl">' + p + "</div>"; }).join("") : '<div class="is-dim">LOADING TAF...</div>';
    this.set("taf", t);
  };

  return IdsView;
})();
// In the sim this view runs inside the screen host (Screen/Screen.js).

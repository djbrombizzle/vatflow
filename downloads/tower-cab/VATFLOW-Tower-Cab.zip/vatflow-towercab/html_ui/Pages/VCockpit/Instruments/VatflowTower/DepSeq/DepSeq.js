/*
 * VATFLOW Tower Cab - departure sequence screens (apps on any screen's MENU):
 *
 *   DEP SEQ    each departure runway's queue in the VATFLOW Taxi Sequencer's order: who goes
 *              next, their departure fix (SID + next fix, in the fix's colour: its bearing from
 *              the field), the first fix of their SID off that runway (right), the interval each
 *              needs behind the one ahead (DIV 1 mile on diverging courses or runway separation,
 *              TRL 3 miles in trail, WAKE 2 / 3 minutes behind a heavy / super); UP marks someone
 *              moved ahead of first come, first served. No countdowns. Underneath, the fixes still
 *              closed behind a departure.
 *   DEP TIMER  one panel per departure runway: the time since the last takeoff roll and the
 *              countdown until the next aircraft in the sequence has its interval behind it
 *              (amber), then RELEASE (green).
 *
 * Both draw the sequence the strip bay feed works out every 20 s (common/dep-seq.js, kept as
 * DEPSEQ_<ICAO>); DEP TIMER counts down between updates. Tap a row / panel to pick that aircraft on the
 * radars and strips (VatflowOps.select).
 */
var DepSeqView = (function () {
  var MAX_COLS = 3;

  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function mmss(s) { return VatflowDepSeq.mmss(s); }
  function wakeMark(w) { return w === "super" ? " J" : w === "heavy" ? " H" : ""; }

  /** "WAKE 2:00", "TRL 3NM", "DIV 1NM", "RWY SEP" for a row's interval. */
  function interval(r) {
    if (!r || r.kind === "first" || !r.sec) return "";
    if (r.kind === "wake") return "WAKE " + mmss(r.sec);
    if (r.rule === "3-9-6a") return "RWY SEP " + mmss(r.sec);
    if (r.kind === "diverge") return "DIV 1NM";
    if (r.kind === "simul") return "SIMUL";
    return "TRL 3NM";
  }

  /** The runways worth a column: those with a queue or a recent departure, else the first ones. */
  function columns(m) {
    var busy = m.runways.filter(function (r) { return r.rows.length || r.last; });
    return (busy.length ? busy : m.runways).slice(0, MAX_COLS);
  }

  function DepSeqView(el, cfg) {
    this.el = el;
    this.cfg = cfg;
    this.last = "";
    this.hits = {};
    el.innerHTML = '<div class="dq-root"><div class="dq-top"><span class="dq-title">DEP SEQ</span><span class="dq-icao"></span>' +
      '<span class="dq-rwys"></span><span class="dq-taxi"></span><span class="dq-zulu"></span></div><div class="dq-body"></div>' +
      '<div class="dq-fixes"></div><div class="dq-foot">VATFLOW TAXI SEQUENCER - INTERVALS PER FAA JO 7110.65 (DIV 1 NM / RWY SEP, ' +
      'TRL 3 NM, WAKE 2-3 MIN) - TAP A ROW TO PICK IT ON THE RADARS</div></div>';
    var q = function (c) { return el.querySelector(c); };
    this.f = { icao: q(".dq-icao"), rwys: q(".dq-rwys"), taxi: q(".dq-taxi"), zulu: q(".dq-zulu"), body: q(".dq-body"), fixes: q(".dq-fixes") };
    var self = this;
    this.f.body.addEventListener("mouseup", function (ev) {
      var t = ev.target;
      while (t && t !== self.f.body && !(t.getAttribute && t.getAttribute("data-cs"))) t = t.parentNode;
      var cs = t && t.getAttribute ? t.getAttribute("data-cs") : null;
      if (cs && typeof VatflowOps !== "undefined") VatflowOps.select(VatflowOps.selected() === cs ? null : cs);
    });
  }

  DepSeqView.interval = interval;
  DepSeqView.columns = columns;

  /** The HTML of the sequence at time now (ms). */
  DepSeqView.html = function (m, now, sel) {
    if (!m) return '<div class="dq-msg">WAITING FOR THE DEPARTURE SEQUENCE<br>(WORKED OUT WITH THE STRIP BAYS\' FEED EVERY 20 S)</div>';
    var el = Math.max(0, (now - m.at) / 1000), cols = columns(m), h = "";
    if (!cols.length) return '<div class="dq-msg">NO RUNWAYS KNOWN FOR ' + esc(m.icao) + "</div>";
    cols.forEach(function (rw) {
      h += '<div class="dq-col" style="width:' + Math.floor(100 / cols.length) + '%"><div class="dq-rh">RWY ' + esc(rw.id) +
        '<span class="dq-n">' + rw.rows.length + " IN SEQ" + (rw.saved >= 30 ? " - SAVES " + mmss(rw.saved) : "") + "</span></div>";
      if (rw.last) {
        h += '<div class="dq-last">LAST <b>' + esc(rw.last.cs) + "</b> " + esc(rw.last.type) + wakeMark(rw.last.wake) +
          ' <span style="color:' + rw.last.color + '">' + esc(rw.last.label) + "</span> " + mmss(rw.last.ago + el) + " AGO</div>";
      } else h += '<div class="dq-last dq-dim">NO DEPARTURE IN THE LAST 4 MIN</div>';
      if (!rw.rows.length) h += '<div class="dq-empty">NOBODY TAXIING FOR ' + esc(rw.id) + "</div>";
      rw.rows.forEach(function (r) {
        h += '<div class="dq-row' + (sel === r.cs ? " dq-sel" : "") + '" data-cs="' + esc(r.cs) + '"><div class="dq-l1"><span class="dq-num">' + r.n +
          '</span><span class="dq-cs">' + esc(r.cs) + '</span><span class="dq-type">' + esc(r.type) + wakeMark(r.wake) + "</span>" +
          (r.jumped ? '<span class="dq-up">UP</span>' : "") + '<span class="dq-t">' + esc(r.first || "") + "</span></div>" +
          '<div class="dq-l2"><span class="dq-fix" style="color:' + r.color + ";border-left-color:" + r.color + '">' + esc(r.label) + "</span>" +
          '<span class="dq-iv dq-' + r.kind + '">' + interval(r) + (r.held ? " FIX HELD" : "") + "</span></div></div>";
      });
      h += "</div>";
    });
    return h;
  };

  DepSeqView.prototype.render = function () {
    var now = Date.now(), m = VatflowDepSeq.stored(this.cfg.icao, now), f = this.f;
    var ops = VatflowStore.get("TWROPS_" + this.cfg.icao, null);
    var sel = typeof VatflowOps !== "undefined" ? VatflowOps.selected() : null;
    var html = DepSeqView.html(m, now, sel);
    if (html !== this.last) { f.body.innerHTML = html; this.last = html; }
    f.icao.textContent = this.cfg.icao;
    f.rwys.textContent = m ? "DEP " + m.depIds.join(" ") + (m.depSrc ? " (" + m.depSrc + ")" : "") + (m.nav ? "" : "  NAV DATA LOADING") : "";
    f.taxi.textContent = ops && ops.taxi && ops.taxi.avg ? "TAXI OUT " + mmss(ops.taxi.avg) : "";
    var z = VatflowDraw.zulu(VatflowDraw.zuluNow());
    f.zulu.textContent = z.hh + z.mm + ":" + z.ss + "Z";
    var fx = "";
    if (m) {
      var el = (now - m.at) / 1000;
      for (var k in m.fixClocks) {
        var left = m.fixClocks[k] - el;
        if (left > 0) fx += '<span class="dq-fc">' + esc(k) + "</span>";
      }
    }
    fx = fx ? '<span class="dq-fh">FIXES CLOSED (3 NM IN TRAIL)</span>' + fx : '<span class="dq-fh">ALL DEPARTURE FIXES OPEN</span>';
    if (fx !== this.lastFx) { f.fixes.innerHTML = fx; this.lastFx = fx; }
  };

  return DepSeqView;
})();

var DepTimerView = (function () {
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function mmss(s) { return VatflowDepSeq.mmss(s); }

  /**
   * One runway's timer at el seconds after the sequence was worked out:
   * {since (s since the last roll or null), next (row or null), left (s until next may roll), state: "wait" | "go" | "idle"}
   */
  function timer(rw, el) {
    var since = rw.last ? rw.last.ago + el : null, next = rw.rows[0] || null, left = 0;
    if (next) {
      if (since !== null && next.sec) left = next.sec - since;
      if (next.held) left = Math.max(left, next.t - el);
    }
    return { since: since, next: next, left: Math.max(0, Math.round(left)), state: !next ? "idle" : left > 0.5 ? "wait" : "go" };
  }

  function DepTimerView(el, cfg) {
    this.el = el;
    this.cfg = cfg;
    this.last = "";
    el.innerHTML = '<div class="dt-root"><div class="dq-top"><span class="dq-title">DEP TIMER</span><span class="dq-icao"></span>' +
      '<span class="dq-rwys"></span><span class="dq-zulu"></span></div><div class="dt-body"></div></div>';
    var q = function (c) { return el.querySelector(c); };
    this.f = { icao: q(".dq-icao"), rwys: q(".dq-rwys"), zulu: q(".dq-zulu"), body: q(".dt-body") };
    var self = this;
    this.f.body.addEventListener("mouseup", function (ev) {
      var t = ev.target;
      while (t && t !== self.f.body && !(t.getAttribute && t.getAttribute("data-cs"))) t = t.parentNode;
      var cs = t && t.getAttribute ? t.getAttribute("data-cs") : null;
      if (cs && typeof VatflowOps !== "undefined") VatflowOps.select(cs);
    });
  }

  DepTimerView.timer = timer;

  DepTimerView.html = function (m, now) {
    if (!m) return '<div class="dq-msg">WAITING FOR THE DEPARTURE SEQUENCE<br>(WORKED OUT WITH THE STRIP BAYS\' FEED EVERY 20 S)</div>';
    var el = Math.max(0, (now - m.at) / 1000), cols = DepSeqView.columns(m), h = "";
    cols.forEach(function (rw) {
      var t = timer(rw, el), n = t.next;
      h += '<div class="dt-pan dt-' + t.state + '"' + (n ? ' data-cs="' + esc(n.cs) + '"' : "") + ' style="height:' + Math.floor(100 / cols.length) + '%">' +
        '<div class="dt-rwy">' + esc(rw.id) + "</div>" +
        '<div class="dt-big">' + (t.state === "wait" ? mmss(t.left) : t.state === "go" ? "RELEASE" : (t.since !== null ? mmss(t.since) : "--:--")) + "</div>" +
        '<div class="dt-info">';
      if (n) {
        h += '<div class="dt-next">NEXT <b>' + esc(n.cs) + "</b> " + esc(n.type) + ' <span style="color:' + n.color + '">' + esc(n.label) + "</span></div>" +
          '<div class="dt-why">' + (rw.last ? esc(DepSeqView.interval(n) || "NO INTERVAL") + " BEHIND " + esc(rw.last.cs) + " " + esc(rw.last.type) +
            (rw.last.wake === "heavy" ? " (HEAVY)" : rw.last.wake === "super" ? " (SUPER)" : "") : "NO DEPARTURE AHEAD") + (n.held ? " - FIX HELD" : "") + "</div>";
      } else h += '<div class="dt-next dq-dim">NOBODY IN SEQUENCE</div>';
      h += '<div class="dt-since">' + (t.since !== null ? "SINCE LAST ROLL " + mmss(t.since) + " (" + esc(rw.last.cs) + ")" : "NO DEPARTURE IN THE LAST 4 MIN") +
        (rw.rows.length > 1 ? " - THEN " + rw.rows.slice(1, 4).map(function (r) { return esc(r.cs); }).join(" ") : "") + "</div></div></div>";
    });
    return h || '<div class="dq-msg">NO DEPARTURE RUNWAYS</div>';
  };

  DepTimerView.prototype.render = function () {
    var now = Date.now(), m = VatflowDepSeq.stored(this.cfg.icao, now), f = this.f;
    var html = DepTimerView.html(m, now);
    if (html !== this.last) { f.body.innerHTML = html; this.last = html; }
    f.icao.textContent = this.cfg.icao;
    f.rwys.textContent = m ? "DEP " + m.depIds.join(" ") + (m.depSrc ? " (" + m.depSrc + ")" : "") : "";
    var z = VatflowDraw.zulu(VatflowDraw.zuluNow());
    f.zulu.textContent = z.hh + z.mm + ":" + z.ss + "Z";
  };

  return DepTimerView;
})();
// In the sim these views run inside the screen host (Screen/Screen.js).

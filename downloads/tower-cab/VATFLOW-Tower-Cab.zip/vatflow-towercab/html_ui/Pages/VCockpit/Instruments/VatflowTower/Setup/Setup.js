/*
 * VATFLOW Tower Cab - SETUP screen (an app on any 1024x768 cab screen, via the screen
 * menu). Puts the cab in the tower and lets you move it there with on-screen buttons:
 *   PLACE IN TOWER    go to the spot (your saved one, the tower list, or OpenStreetMap's)
 *   arrows / UP / DN / TURN   nudge by the chosen step, frozen again after each move; the
 *                     new spot is saved for this airport as soon as the cab gets there
 *   SAVE THIS SPOT    remember where the cab is now for this airport (the sim's storage, per
 *                     user), e.g. after moving it some other way (slew, the placement tool)
 *   RELEASE           unfreeze (slew / fly it yourself)
 *   AUTO PLACE        go to the tower by itself when a flight starts at this airport
 *   VATSIM CID        your CID for the IDST (typed on the keypad, kept per user)
 *   HALLOWEEN         show / hide the seasonal decorations in the cab (kept per user)
 * Plain DOM code, also used by the browser preview (where nothing can move).
 */
var SetupView = (function () {
  var STEPS = [[0.5, 1], [2, 5], [10, 15]];       // [meters / feet, degrees]
  var MONTHS = "JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC".split(" ");

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  var HTML =
    '<div class="su-root">' +
    '<div class="su-top"><span class="su-title">TOWER SETUP</span><span class="su-apt" data-f="apt">----</span><span class="su-zulu" data-f="zulu">----Z</span></div>' +
    '<div class="su-state" data-f="state">LOCATING AIRPORT...</div>' +
    '<div class="su-line"><span class="su-k">SPOT</span><span data-f="src">-</span></div>' +
    '<div class="su-line"><span class="su-k">TARGET</span><span data-f="target">-</span></div>' +
    '<div class="su-line"><span class="su-k">CAB NOW</span><span data-f="now">-</span></div>' +
    '<div class="su-main">' +
    '  <div class="su-col">' +
    '    <div class="su-btn su-big su-go" data-k="place">PLACE IN TOWER</div>' +
    '    <div class="su-btn su-big" data-k="save">SAVE THIS SPOT</div>' +
    '    <div class="su-row2"><div class="su-btn su-half" data-k="release">RELEASE</div><div class="su-btn su-half" data-k="forget">FORGET SPOT</div></div>' +
    '    <div class="su-btn su-check" data-k="auto"><span data-f="auto">[X]</span> AUTO PLACE ON SPAWN</div>' +
    '    <div class="su-row2 su-tfc"><span class="su-k">TRAFFIC</span><div class="su-btn su-chip" data-k="tfcVATSIM">VATSIM</div>' +
    '      <div class="su-btn su-chip" data-k="tfcSIM">SIM</div></div>' +
    '  </div>' +
    '  <div class="su-col su-pad">' +
    '    <div class="su-ph">MOVE THE CAB <span data-f="step"></span></div>' +
    '    <div class="su-steps"><div class="su-btn su-chip" data-k="step0">FINE</div><div class="su-btn su-chip" data-k="step1">MEDIUM</div><div class="su-btn su-chip" data-k="step2">BIG</div></div>' +
    '    <div class="su-grid">' +
    '      <div class="su-btn su-arrow" data-k="tl">TURN L</div><div class="su-btn su-arrow" data-k="fwd">FWD</div><div class="su-btn su-arrow" data-k="tr">TURN R</div>' +
    '      <div class="su-btn su-arrow" data-k="left">LEFT</div><div class="su-mid">CAB</div><div class="su-btn su-arrow" data-k="right">RIGHT</div>' +
    '      <div class="su-btn su-arrow" data-k="up">UP</div><div class="su-btn su-arrow" data-k="back">BACK</div><div class="su-btn su-arrow" data-k="down">DOWN</div>' +
    '    </div>' +
    '    <div class="su-hint">FWD / BACK / LEFT / RIGHT ARE AS SEEN LOOKING OUT THE FRONT WINDOW</div>' +
    '  </div>' +
    '</div>' +
    '<div class="su-cid su-brt"><span class="su-k">BRIGHTNESS</span><span data-f="brt">-</span>' +
    '  <div class="su-btn su-chip su-wide" data-k="dim">DIMMER</div><div class="su-btn su-chip su-wide" data-k="bright">BRIGHTER</div>' +
    '  <div class="su-btn su-chip su-wide su-check" data-k="brtauto"><span data-f="brtauto">[X]</span> AUTO</div>' +
    '  <div class="su-btn su-chip su-wide su-check" data-k="litauto"><span data-f="litauto">[X]</span> CAB LIGHTS</div></div>' +
    '<div class="su-cid su-sync"><span class="su-k">STRIP SYNC</span><span data-f="sync">-</span>' +
    '  <div class="su-btn su-chip su-check" data-k="syncon"><span data-f="syncon">[ ]</span> ON</div>' +
    '  <div class="su-btn su-chip" data-k="synccode">CODE</div><div class="su-btn su-chip" data-k="syncnew">NEW</div></div>' +
    '<div class="su-cid"><span class="su-k">VATSIM CID</span><span data-f="cid">-</span><div class="su-btn su-chip" data-k="cid">EDIT</div>' +
    '  <div class="su-btn su-chip su-check su-decor" data-k="decor"><span data-f="decor">[X]</span> HALLOWEEN</div>' +
    '  <div class="su-keys" data-f="keys"></div></div>' +
    '<div class="su-msg" data-f="msg"></div>' +
    "</div>";

  function SetupView(root, cfg) {
    this.root = root;
    this.cfg = cfg;
    root.innerHTML = HTML;
    this.f = {};
    var fs = root.querySelectorAll("[data-f]");
    for (var i = 0; i < fs.length; i++) this.f[fs[i].getAttribute("data-f")] = fs[i];
    this.step = 1;
    this.site = null;
    this.data = null;
    this.tgt = null;
    this.msg = "";
    this.cidEdit = null;     // digits typed so far while editing
    this.syncEdit = null;    // the STRIP SYNC code typed so far while editing
    this.preview = null;     // the cab's position in the browser preview (nothing moves there)
    var self = this;
    var btns = root.querySelectorAll("[data-k]");
    for (var j = 0; j < btns.length; j++) {
      (function (b) {
        b.addEventListener("mouseup", function (e) { if (e && e.stopPropagation) e.stopPropagation(); self.key(b.getAttribute("data-k")); });
      })(btns[j]);
    }
    this.nudged = null;      // {icao, pos} of the last nudge: saved once the cab is there
    if (typeof VatflowPlace !== "undefined") VatflowPlace.onState(function (state, msg) {
      var n = self.nudged;
      if (state === "placed" && n) { self.nudged = null; self.saveSpot(n.icao, n.pos, "MOVED AND SAVED FOR "); return; }
      if (state === "error" || state === "released") self.nudged = null;
      self.say(msg);
    });
  }

  SetupView.prototype.start = function () {
    var self = this;
    VatflowSite.resolve(function (s) {
      self.site = s;
      self.refreshTarget();
      VatflowSite.loadData(function (d, err) {
        self.data = d;
        if (err) self.say("NO MAP DATA: " + err.message);
        self.refreshTarget();
      });
    });
  };

  SetupView.prototype.refreshTarget = function () {
    if (!this.site) return;
    this.tgt = VatflowPlace.target(this.site.icao, this.site, this.data);
  };

  SetupView.prototype.say = function (m) { this.msg = m || ""; this.msgAt = Date.now(); };

  /** Where the cab is: the sim's position, or (preview) the one we pretend to have. */
  SetupView.prototype.cab = function () {
    return VatflowPlace.here() || this.preview || (this.tgt && this.tgt.pos) || null;
  };

  SetupView.prototype.goTo = function (pos, small) {
    if (typeof SimVar === "undefined") { this.preview = pos; this.say("PREVIEW: NOTHING MOVES OUTSIDE THE SIM"); return; }
    VatflowPlace.place(pos, small);
  };

  /**
   * Saves pos as icao's tower spot, reads it back and says how it went. Before this, a nudge
   * only moved the cab: the next flight went back to the old spot unless SAVE THIS SPOT was
   * pressed, which is what people reported as "the position isn't saved".
   */
  SetupView.prototype.saveSpot = function (icao, pos, what) {
    var p = VatflowPlace.save(icao, pos);
    this.refreshTarget();
    this.say(p ? what + icao + ": " + this.fmt(p) : "COULD NOT SAVE: THE SIM'S STORAGE DID NOT KEEP THE SPOT");
  };

  SetupView.prototype.key = function (k) {
    var icao = this.site && this.site.icao;
    if (this.cidEdit !== null && k.indexOf("n") === 0) { this.cidKey(k.slice(1)); return; }
    if (this.syncEdit !== null && k.indexOf("n") === 0) { this.syncKey(k.slice(1)); return; }
    if (k.indexOf("step") === 0) { this.step = +k.slice(4); return; }
    if (k === "cid") { this.syncEdit = null; this.cidEdit = this.cidEdit === null ? "" : null; return; }
    if (this.syncCmd(k)) return;
    if (k === "tfcVATSIM" || k === "tfcSIM") {
      VatflowTraffic.setSource(k.slice(3));
      this.say(k === "tfcSIM" ? "RADARS: TRAFFIC IN YOUR SIM (AI, INJECTED, VPILOT), UPDATED EVERY SECOND" : "RADARS: VATSIM FEED (ABOUT EVERY 15 S)");
      return;
    }
    if (this.brightKey(k)) return;
    if (k === "decor") { this.decor(!this.decorOn()); return; }
    if (!icao || icao === "----") { this.say("NO AIRPORT FOUND NEAR THE CAB"); return; }
    if (k === "place") {
      this.refreshTarget();
      if (this.tgt) this.goTo(this.tgt.pos, false);
      return;
    }
    if (k === "release") { if (typeof SimVar !== "undefined") VatflowPlace.release(); else this.say("RELEASED (PREVIEW)"); return; }
    if (k === "save") {
      var cur = this.cab();
      if (!cur) return;
      this.saveSpot(icao, cur, "SAVED FOR ");
      return;
    }
    if (k === "forget") {
      VatflowPlace.forget(icao);
      this.refreshTarget();
      this.say("SAVED SPOT FORGOTTEN - NOW USING " + (this.tgt ? this.tgt.src : "-"));
      return;
    }
    if (k === "auto") { VatflowStore.set("AUTO_PLACE", !this.auto()); return; }
    var s = STEPS[this.step], base = this.cab();
    if (!base) return;
    var mv = {
      fwd: [s[0], 0, 0, 0], back: [-s[0], 0, 0, 0], left: [0, -s[0], 0, 0], right: [0, s[0], 0, 0],
      up: [0, 0, s[0] * 2, 0], down: [0, 0, -s[0] * 2, 0], tl: [0, 0, 0, -s[1]], tr: [0, 0, 0, s[1]]
    }[k];
    if (!mv) return;
    var to = VatflowPlace.move(base, mv[0], mv[1], mv[2], mv[3]);
    if (typeof SimVar === "undefined") { this.preview = to; this.saveSpot(icao, to, "PREVIEW: MOVED AND SAVED FOR "); return; }
    this.nudged = { icao: icao, pos: to };
    this.goTo(to, true);
  };

  /**
   * Brightness row: DIMMER / BRIGHTER move the ALL screens knob (L:VATFLOW_DIM_ALL, 0 .. 90 =
   * darkest); with that knob full up BRIGHTER goes on past 100 % to 200 % in 20 % steps
   * (L:VATFLOW_BOOST, kept for the next flight) and DIMMER comes back down to 100 % first. AUTO dims the screens at night, CAB LIGHTS switches the ceiling lights off and
   * the console lights on at night (common/dimmer.js). The AUTO choices are kept.
   */
  SetupView.prototype.brightKey = function (k) {
    var sim = typeof SimVar !== "undefined";
    if (k === "dim" || k === "bright") {
      var v = sim ? SimVar.GetSimVarValue("L:VATFLOW_DIM_ALL", "number") || 0 : (this.dimAll || 0);
      var boost = Math.round(VatflowDimmer.boostFactor(sim ? SimVar.GetSimVarValue("L:VATFLOW_BOOST", "number") : this.boost) * 100);
      if (k === "bright" && v <= 0) boost = Math.min(200, boost + 20);
      else if (k === "dim" && boost > 100) boost = Math.max(100, boost - 20);
      else v = Math.max(0, Math.min(90, Math.round((v + (k === "dim" ? 10 : -10)) / 10) * 10));
      if (sim) {
        SimVar.SetSimVarValue("L:VATFLOW_DIM_ALL", "number", v);
        SimVar.SetSimVarValue("L:VATFLOW_BOOST", "number", boost);
      } else { this.dimAll = v; this.boost = boost; }
      VatflowStore.set("BOOST", boost);
      return true;
    }
    if (k === "brtauto" || k === "litauto") {
      var key = k === "brtauto" ? "DIM_AUTO" : "LIGHTS_AUTO", on = VatflowStore.get(key, true) === false;
      VatflowStore.set(key, on);
      if (sim) SimVar.SetSimVarValue(k === "brtauto" ? "L:VATFLOW_DIM_MANUAL" : "L:VATFLOW_LIGHTS_MANUAL", "number", on ? 0 : 1);
      this.say(k === "brtauto" ? (on ? "SCREENS DIM BY THEMSELVES AT NIGHT" : "SCREENS: KNOBS ONLY")
        : (on ? "CAB LIGHTS: CONSOLE LIGHTS AT NIGHT, CEILING BY DAY (WITHIN 10 S)" : "CAB LIGHTS: ALWAYS ON"));
      return true;
    }
    return false;
  };

  /**
   * HALLOWEEN: the seasonal decorations (the jack-o'-lantern and the rest, model nodes shown
   * while L:VATFLOW_DECOR_OFF is 0). Kept in VatflowStore "DECOR"; common/dimmer.js sets the
   * L: var from it when a flight starts.
   */
  SetupView.prototype.decorOn = function () { return VatflowStore.get("DECOR", true) !== false; };
  SetupView.prototype.decor = function (on) {
    VatflowStore.set("DECOR", on);
    if (typeof SimVar !== "undefined") SimVar.SetSimVarValue("L:VATFLOW_DECOR_OFF", "number", on ? 0 : 1);
    this.say(on ? "HALLOWEEN DECORATIONS ON (CLICK THE PUMPKIN TO BLOW OUT ITS CANDLE)" : "HALLOWEEN DECORATIONS PUT AWAY");
  };

  SetupView.prototype.auto = function () { return VatflowStore.get("AUTO_PLACE", true) !== false; };

  /**
   * STRIP SYNC (common/strip-sync.js, run by strip bay 1's screen): ON shares this airport's
   * strips with every cab using the same 6-digit code; CODE types the code your tower uses,
   * NEW makes one up (give it to the others). Kept in VatflowStore "STRIPSYNC".
   */
  SetupView.prototype.syncCmd = function (k) {
    var cur = VatflowStore.get("STRIPSYNC", null) || { on: false, code: "" };
    if (k === "synccode") { this.cidEdit = null; this.syncEdit = this.syncEdit === null ? "" : null; return true; }
    if (k === "syncnew") {
      var code = VatflowStripSync.newCode();
      VatflowStore.set("STRIPSYNC", { on: true, code: code });
      this.syncEdit = null;
      this.say("STRIP SYNC ON - NEW CODE " + code + ": GIVE IT TO THE OTHER CONTROLLERS AT THIS AIRPORT");
      return true;
    }
    if (k === "syncon") {
      if (!cur.on && !/^\d{6}$/.test(cur.code || "")) { this.syncEdit = ""; this.say("TYPE YOUR TOWER'S 6-DIGIT CODE FIRST (OR NEW)"); return true; }
      VatflowStore.set("STRIPSYNC", { on: !cur.on, code: cur.code });
      this.say(cur.on ? "STRIP SYNC OFF - YOUR STRIPS STAY AS THEY ARE" : "STRIP SYNC ON - CODE " + cur.code);
      return true;
    }
    return false;
  };

  SetupView.prototype.syncKey = function (d) {
    if (d === "ok") {
      if (!/^\d{6}$/.test(this.syncEdit)) { this.say("THE CODE IS 6 DIGITS"); return; }
      VatflowStore.set("STRIPSYNC", { on: true, code: this.syncEdit });
      this.say("STRIP SYNC ON - CODE " + this.syncEdit + " (A ROOM IN USE REPLACES YOUR STRIPS WITH ITS OWN)");
      this.syncEdit = null;
    } else if (d === "clr") this.syncEdit = "";
    else if (this.syncEdit.length < 6) this.syncEdit += d;
  };

  /** The STRIP SYNC line: off / connecting / who is in the room. */
  SetupView.prototype.syncText = function () {
    if (this.syncEdit !== null) return (this.syncEdit || "_") + "  (TYPE THE 6-DIGIT CODE, THEN OK)";
    var cur = VatflowStore.get("STRIPSYNC", null), st = VatflowStore.get("STRIPSYNC_STATUS", null);
    if (!cur || !cur.on) return "OFF" + (cur && cur.code ? " (CODE " + cur.code + ")" : " - SHARE STRIPS WITH OTHER CABS HERE");
    if (!st || st.state === "off") return "STARTING... CODE " + cur.code + " (NEEDS THE STRIP BAYS)";
    var room = cur.code + (st.error ? " - " + st.error : "");
    if (st.state !== "ok") return "CONNECTING... CODE " + room;
    var peers = st.peers || [];
    return "CODE " + room + " - " + peers.length + (peers.length === 1 ? " CAB (JUST YOU)" : " CABS: " + peers.join(" "));
  };

  SetupView.prototype.cidKey = function (d) {
    if (d === "ok") {
      VatflowStore.set("CID", this.cidEdit);
      if (this.cfg.idst) this.cfg.idst.cid = this.cidEdit;
      if (typeof SimVar !== "undefined") SimVar.SetSimVarValue("L:VATFLOW_CID_CHANGED", "number", Date.now() / 1000);
      this.say(this.cidEdit ? "CID " + this.cidEdit + " SAVED" : "CID CLEARED");
      this.cidEdit = null;
    } else if (d === "clr") this.cidEdit = "";
    else if (this.cidEdit.length < 8) this.cidEdit += d;
  };

  SetupView.prototype.fmt = function (p) {
    if (!p) return "-";
    return p.lat.toFixed(6) + "  " + p.lon.toFixed(6) + "   FLOOR " + Math.round(p.floorFtMsl) + " FT MSL   FACING " +
      VatflowFeed.pad(Math.round(p.headingTrue) % 360, 3) + " T";
  };

  SetupView.prototype.render = function () {
    var f = this.f, site = this.site, st = typeof SimVar !== "undefined" ? VatflowPlace.state() : 0;
    var z = VatflowDraw.zulu(VatflowDraw.zuluNow());
    f.zulu.textContent = z.hh + z.mm + "Z";
    f.apt.textContent = site ? site.icao + "  " + (site.name || "") : "----";
    var state;
    if (!site) state = "LOCATING AIRPORT...";
    else if (VatflowPlace.busy()) state = "MOVING THE CAB...";
    else if (st === 1) state = "IN THE TOWER - FROZEN" + (VatflowPlace.method() === 2 ? " (SLEW)" : "");
    else if (st === 2) state = "RELEASED - THE CAB IS FREE TO MOVE";
    else state = typeof SimVar === "undefined" ? "BROWSER PREVIEW" : "NOT IN THE TOWER YET - PRESS PLACE IN TOWER";
    f.state.textContent = state;
    f.state.className = "su-state" + (st === 1 ? " ok" : "");
    f.src.textContent = this.tgt ? this.tgt.src : (site ? "LOADING..." : "-");
    f.target.textContent = this.tgt ? this.fmt(this.tgt.pos) : "-";
    var cur = this.cab();
    var off = "";
    if (cur && this.tgt) {
      var e = VatflowPlace.error(this.tgt.pos, cur);
      off = "   (" + (e.distM < 0.3 && Math.abs(e.up) < 0.5 && Math.abs(e.turn) < 0.5 ? "ON TARGET" :
        Math.round(e.fwd * 10) / 10 + " M FWD, " + Math.round(e.right * 10) / 10 + " M RIGHT, " + Math.round(e.up) + " FT UP, " + Math.round(e.turn) + " DEG") + ")";
    }
    f.now.textContent = (VatflowPlace.here() ? this.fmt(cur) : "-") + (VatflowPlace.here() ? off : "");
    var s = STEPS[this.step];
    f.step.textContent = "- STEP " + s[0] + " M / " + s[0] * 2 + " FT / " + s[1] + " DEG";
    var chips = this.root.querySelectorAll(".su-chip[data-k^=step]");
    for (var i = 0; i < chips.length; i++) chips[i].className = "su-btn su-chip" + (i === this.step ? " on" : "");
    f.auto.textContent = this.auto() ? "[X]" : "[ ]";
    var sim = typeof SimVar !== "undefined", dimAuto = VatflowStore.get("DIM_AUTO", true) !== false;
    var dimAll = sim ? SimVar.GetSimVarValue("L:VATFLOW_DIM_ALL", "number") || 0 : (this.dimAll || 0);
    var night = sim ? SimVar.GetSimVarValue("L:VATFLOW_NIGHT", "number") || 0 : 0;
    var boost = VatflowDimmer.boostFactor(sim ? SimVar.GetSimVarValue("L:VATFLOW_BOOST", "number") : this.boost);
    var pct = Math.round(VatflowDimmer.level(dimAll, 0) * (dimAuto ? VatflowDimmer.autoFactor(night) : 1) * boost * 100);
    f.brt.textContent = pct + "%" + (night >= 50 ? " NIGHT" : night > 0 ? " DUSK" : " DAY");
    f.brtauto.textContent = dimAuto ? "[X]" : "[ ]";
    f.litauto.textContent = VatflowStore.get("LIGHTS_AUTO", true) !== false ? "[X]" : "[ ]";
    f.decor.textContent = this.decorOn() ? "[X]" : "[ ]";
    var cid = VatflowStore.get("CID", "");
    f.cid.textContent = this.cidEdit !== null ? (this.cidEdit || "_") + "  (TYPE YOUR CID, THEN OK)" : (cid || "NOT SET - NEEDED TO ISSUE IDST RELEASES");
    var src = VatflowTraffic.source(), tc = this.root.querySelectorAll(".su-tfc .su-chip");
    for (var t = 0; t < tc.length; t++) tc[t].className = "su-btn su-chip" + (tc[t].getAttribute("data-k") === "tfc" + src ? " on" : "");
    var sc = VatflowStore.get("STRIPSYNC", null);
    f.sync.textContent = this.syncText();
    f.syncon.textContent = sc && sc.on ? "[X]" : "[ ]";
    var keys = "";
    if (this.cidEdit !== null || this.syncEdit !== null) {
      "123456789".split("").concat(["clr", "0", "ok"]).forEach(function (d) {
        keys += '<div class="su-btn su-num' + (d === "ok" ? " su-go" : "") + '" data-n="' + d + '">' + d.toUpperCase() + "</div>";
      });
    }
    if (keys !== this.lastKeys) {
      f.keys.innerHTML = keys;
      this.lastKeys = keys;
      var self = this, nb = f.keys.querySelectorAll("[data-n]");
      for (var j = 0; j < nb.length; j++) {
        (function (b) {
          b.addEventListener("mouseup", function (e) { if (e && e.stopPropagation) e.stopPropagation(); self.key("n" + b.getAttribute("data-n")); });
        })(nb[j]);
      }
    }
    if (this.msg && Date.now() - this.msgAt > 15000) this.msg = "";
    f.msg.textContent = this.msg;
  };

  SetupView.MONTHS = MONTHS;
  return SetupView;
})();

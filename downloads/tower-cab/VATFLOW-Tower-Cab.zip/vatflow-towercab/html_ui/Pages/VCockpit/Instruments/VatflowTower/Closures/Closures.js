/*
 * VATFLOW Tower Cab - CLOSURES: a map of the airport (the Ground Radar's, common closures.js
 * does the work) where the controller closes runways and taxiways.
 *
 *   tap a runway            closed / open again (red, with an X at each end)
 *   tap a taxiway           first end of the closure (a yellow mark), then
 *   tap a second spot       the other end: the stretch between is closed (hatched)
 *   tap the same spot       only that spot (one row of barricades)
 *   tap a closed taxiway    opens it again
 *
 * The helper on the PC (placement/closures.bat) puts barricades, lighted X's and work
 * vehicles in the sim; the bottom line says whether it is running. Zoom / pan / rotate with the
 * same pad as the Ground Radar. The map is drawn by AsdexView (no traffic).
 */
var ClosuresView = (function () {
  var CL = VatflowClosures;
  var C = { rwy: "#ff3b30", twy: "#ffcc00", pending: "#ffcc00", text: "#d8f0ff", ok: "#4cd964", off: "#ff9500", dim: "#9aa7b4" };

  function ClosuresView(canvas, cfg, maps) {
    this.canvas = canvas;
    this.cfg = cfg;
    this.map = new AsdexView(canvas, cfg, maps);
    this.asdex = maps && maps.asdex;
    this.st = CL.load(cfg.icao);
    this.pending = null;      // first tap of a taxiway closure
    this.note = "";
    this.noteAt = 0;
    this.link = null;
  }

  ClosuresView.prototype.setView = function (v) { this.map.setView(v); };
  ClosuresView.prototype.setUp = function (h) { this.map.setUp(h); };
  ClosuresView.prototype.fit = function () { this.map.fit(); };

  ClosuresView.prototype.start = function () {
    var self = this;
    this.link = CL.link(function () { self.refresh(); return CL.payload(self.cfg, self.asdex, self.st); });
  };

  /** Every screen showing CLOSURES keeps its own copy and talks to the helper: take a newer
   *  list another screen saved, or the screens take turns sending the helper their own. */
  ClosuresView.prototype.refresh = function () {
    var s = CL.load(this.cfg.icao);
    if (s.rev > this.st.rev) this.st = s;
  };
  ClosuresView.prototype.stop = function () { if (this.link) this.link.stop(); };

  ClosuresView.prototype.say = function (text) { this.note = text; this.noteAt = Date.now(); };

  ClosuresView.prototype.changed = function () {
    CL.save(this.cfg.icao, this.st);
    if (this.link) this.link.kick();
  };

  /** Canvas pixels -> meters east / north of the ARP (inverse of AsdexView.px). */
  ClosuresView.prototype.meters = function (px, py) {
    var m = this.map, qx = (px - m.cx) / m.scale, qy = (m.cy - py) / m.scale;
    var a = -m.upHdg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
    return { x: qx * c - qy * s, y: qx * s + qy * c };
  };

  ClosuresView.prototype.tap = function (px, py) {
    this.refresh();
    var p = this.meters(px, py), h = CL.hit(this.cfg, this.asdex, this.st, p.x, p.y, 14 / this.map.scale);
    if (this.pending) {
      if (!h || h.type !== "twy") { this.say("TAP A TAXIWAY FOR THE OTHER END, OR CANCEL"); return; }
      var c = CL.addTaxiway(this.st, this.pending, h);
      this.pending = null;
      this.say("TWY " + (c.ref || "") + (c.b ? " CLOSED" : " CLOSED AT ONE SPOT"));
      this.changed();
      return;
    }
    if (!h) return;
    if (h.type === "closure") {
      var gone = this.st.twys.splice(h.index, 1)[0];
      this.say("TWY " + (gone.ref || "") + " OPEN");
      this.changed();
    } else if (h.type === "rwy") {
      CL.toggleRunway(this.st, h.id);
      this.say("RWY " + h.id + (this.st.rwys[h.id] ? " CLOSED" : " OPEN"));
      this.changed();
    } else {
      this.pending = h;
      this.say("TWY " + (h.ref || "") + ": TAP THE OTHER END (SAME SPOT = ONE ROW)");
    }
  };

  ClosuresView.prototype.cancel = function () { this.pending = null; this.say(""); };

  ClosuresView.prototype.clearAll = function () {
    this.refresh();
    this.st.rwys = {};
    this.st.twys = [];
    this.pending = null;
    this.say("ALL OPEN");
    this.changed();
  };

  ClosuresView.prototype.draw = function (nowMs) {
    var g = this.map.ctx, m = this.map, i, W = this.canvas.width, H = this.canvas.height;
    var mono = VatflowDraw.mono, CW = 12, blink = Math.floor(nowMs / 500) % 2 === 0;
    this.refresh();
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.globalAlpha = 1;
    m.drawMap(g);
    m.drawLabels(g);
    var px = function (x, y) { return m.px(x, y); };

    // closed runways: red over the runway, a white X at each end
    var rs = CL.runways(this.cfg, this.asdex);
    for (i = 0; i < rs.length; i++) {
      if (!this.st.rwys[rs[i].id]) continue;
      var a = px(rs[i].ends[0].x, rs[i].ends[0].y), b = px(rs[i].ends[1].x, rs[i].ends[1].y);
      g.strokeStyle = C.rwy;
      g.globalAlpha = 0.55;
      g.lineCap = "butt";
      g.lineWidth = Math.max(6, rs[i].w * m.scale);
      g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke();
      g.globalAlpha = 1;
      var objs = CL.objects(this.cfg, this.asdex, { rwys: (function () { var o = {}; o[rs[i].id] = 1; return o; })(), twys: [] });
      for (var k = 0; k < objs.length; k++) {
        var q = px(objs[k].x, objs[k].y), r = Math.max(6, 9 * m.scale);
        g.strokeStyle = blink ? "#ffffff" : "#ffd0d0";
        g.lineWidth = 3;
        g.beginPath(); g.moveTo(q.x - r, q.y - r); g.lineTo(q.x + r, q.y + r); g.moveTo(q.x + r, q.y - r); g.lineTo(q.x - r, q.y + r); g.stroke();
      }
    }

    // closed taxiways: yellow stretch, red barricade rows at the ends
    for (i = 0; i < this.st.twys.length; i++) {
      var c = this.st.twys[i], pts = CL.closurePoints(this.asdex, c);
      g.strokeStyle = C.twy;
      g.globalAlpha = 0.6;
      g.lineCap = "round";
      g.lineJoin = "round";
      g.lineWidth = Math.max(5, c.w * m.scale);
      g.beginPath();
      for (var j = 0; j < pts.length; j++) { var pp = px(pts[j].x, pts[j].y); if (j) g.lineTo(pp.x, pp.y); else g.moveTo(pp.x, pp.y); }
      if (pts.length === 1) { var p0 = px(pts[0].x, pts[0].y); g.lineTo(p0.x + 0.1, p0.y); }
      g.stroke();
      g.globalAlpha = 1;
      [c.a, c.b].forEach(function (e) {
        if (!e) return;
        var h = (e.hdg - m.upHdg) * Math.PI / 180, q = px(e.x, e.y), half = Math.max(8, (c.w / 2 + 2) * m.scale);
        g.strokeStyle = blink ? C.rwy : "#ff8a80";
        g.lineWidth = 5;
        g.lineCap = "butt";
        g.beginPath();
        g.moveTo(q.x - Math.cos(h) * half, q.y - Math.sin(h) * half);
        g.lineTo(q.x + Math.cos(h) * half, q.y + Math.sin(h) * half);
        g.stroke();
      });
    }

    // first tap of a new closure
    if (this.pending) {
      var pq = px(this.pending.x, this.pending.y);
      g.strokeStyle = C.pending;
      g.lineWidth = 3;
      g.beginPath(); g.arc(pq.x, pq.y, blink ? 12 : 9, 0, Math.PI * 2); g.stroke();
    }

    // header, note, helper status
    g.fillStyle = "rgba(0,0,0,0.55)";
    g.fillRect(0, 0, W, 40);
    g.fillRect(0, H - 34, W, 34);
    g.fillStyle = C.text;
    var nr = Object.keys(this.st.rwys).length, nt = this.st.twys.length;
    mono(g, "CLOSURES " + this.cfg.icao + "   RWY " + (nr ? Object.keys(this.st.rwys).join(" ") : "-") + "   TWY " + nt, 14, 26, CW);
    var ls = this.link ? this.link.status() : { state: "wait" };
    g.fillStyle = ls.state === "ok" ? (ls.error ? C.off : C.ok) : ls.state === "off" ? C.off : C.dim;
    mono(g, ls.state === "ok" ? "SIM HELPER ON - " + ls.count + " OBJECTS" + (ls.error ? " - " + String(ls.error).toUpperCase().slice(0, 40) : "")
      : ls.state === "off" ? "SIM HELPER NOT RUNNING - START closures.bat ON THE PC" : "SIM HELPER ...", 14, H - 12, CW);
    if (this.note && nowMs - this.noteAt < (this.pending ? 600000 : 6000)) {
      g.fillStyle = "rgba(0,0,0,0.7)";
      g.fillRect(0, 44, W, 34);
      g.fillStyle = C.pending;
      mono(g, this.note, 14, 68, CW);
    }
  };

  return ClosuresView;
})();

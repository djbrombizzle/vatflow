/*
 * VATFLOW Tower Cab - departure sequence for the DEP SEQ and DEP TIMER screens and the strip
 * numbers, worked out by the VATFLOW Taxi Sequencer (common/vatflow-taxiseq.js = vatflow's
 * shared/taxi-sequencer.js, the same code as vatflow.io/taxi-sequencer.html).
 *
 * Each departure's fix is its SID + next fix (the filed enroute transition, else the next fix
 * in the route, else the SID's exit fix) from vatflow.io's nav data (FAA CIFP: procedures,
 * fixes, navaids, RNAV SIDs, the runways each SID is published for), loaded once by loadNav.
 * Its bearing from the field sets its colour and the interval it needs behind the departure
 * ahead (FAA JO 7110.65): 1 mile when courses diverge 15 deg or more (10 with both on RNAV
 * SIDs), 3 miles in trail on the same fix, 2 / 3 minutes behind a heavy / super, never less
 * than runway separation (~45 s) off the same runway. The order is the least total wait with
 * nobody jumped more than two places.
 *
 * Which runway: the aircraft's SID rule in the airport's VATFLOW IDST runway / SID config
 * (vatflow.io IDST settings: SID -> runway, shared through the VATFLOW hub, loadTaxiConfig),
 * else the runways the SID is published for among those in use (nearest threshold), else the
 * nearest one in use; an aircraft lined up on a runway is on that one. The IDST config's
 * departure runways, when set, are the ones in use. Each row also names the first fix of its
 * SID off that runway (the runway transition's first waypoint, RNAV SIDs; "" for vectors).
 *
 * compute() runs where the strips are fed (StripBay/StripBay.js, every 20 s, one reader for the
 * cab) and the result is kept in the sim's storage (DEPSEQ_<ICAO>), so the screens only draw it:
 *   {at, icao, nav, depIds, depSrc, runways: [{id, last, rows: [{n, cs, type, wake, fix, label,
 *    color, t, sec, kind, rule, held, jumped, ready, first, rwySrc}]}], fixClocks: {FIX: s}, seq: {CS: {n, rwy, color}}}
 * Times (t, ready, fixClocks, last.ago) are seconds from `at`.
 */
var VatflowDepSeq = (function () {
  var NAV_FILES = { procs: "procedures.json", fixes: "fixes.json", navaids: "navaids.json", rnav: "sid-rnav.json", sidRwys: "sid-runways.json" };
  var RECENT_S = 240;            // departures that still hold the next ones (wake 3 min + a margin)
  var nav = null, navWait = [], navTried = 0;
  var HUB = "https://vatflow-hub-production.up.railway.app";
  var taxiCfg = null, taxiCfgAt = 0, taxiCfgBusy = false;

  /**
   * The VATFLOW IDST runway / SID configs of every airport ({ICAO: {activeRunways, sidRules}}),
   * read from the hub (GET /taxi/config, public) at most once a minute; cb(configs) once a
   * fresh copy is in. The last good copy stays in the sim's storage (TAXICFG) for the next flight.
   */
  function loadTaxiConfig(cb) {
    if (!taxiCfg && typeof VatflowStore !== "undefined") taxiCfg = VatflowStore.get("TAXICFG", null);
    if (taxiCfgBusy || Date.now() - taxiCfgAt < 60000) return;
    taxiCfgBusy = true;
    taxiCfgAt = Date.now();
    var x = new XMLHttpRequest();
    x.open("GET", HUB + "/taxi/config", true);
    x.timeout = 15000;
    x.onreadystatechange = function () {
      if (x.readyState !== 4) return;
      taxiCfgBusy = false;
      var d = null;
      try { d = x.status === 200 ? JSON.parse(x.responseText) : null; } catch (e) { d = null; }
      if (!d || !d.ok || !d.configs) return;
      taxiCfg = d.configs;
      if (typeof VatflowStore !== "undefined") VatflowStore.set("TAXICFG", taxiCfg);
      if (cb) cb(taxiCfg);
    };
    x.send();
  }

  /** One airport's IDST config, cleaned up: {activeRunways: [ids], sidRules: {SIDBASE: id}}. */
  function taxiConfigFor(icao, all) {
    var raw = (all || taxiCfg || {})[icao] || {}, out = { activeRunways: [], sidRules: {} };
    (raw.activeRunways || []).forEach(function (r) { var id = normRwy(r); if (id && out.activeRunways.indexOf(id) < 0) out.activeRunways.push(id); });
    for (var k in raw.sidRules || {}) { var b = sidBase(k), id2 = normRwy(raw.sidRules[k]); if (b && id2) out.sidRules[b] = id2; }
    return out;
  }

  /** "RW09L" / "9l" -> "09L", "" for junk (as vatflow's taxi-estimate normalizeRunway). */
  function normRwy(id) {
    var m = /^(\d{1,2})([LCRB]?)$/.exec(String(id || "").trim().toUpperCase().replace(/^RW/, ""));
    if (!m || +m[1] < 1 || +m[1] > 36) return "";
    return (+m[1] < 10 ? "0" : "") + +m[1] + m[2];
  }

  /** BANNG3 -> BANNG (IDST rules are kept by the SID's base name, so a new revision keeps its rule). */
  function sidBase(name) { return String(name || "").trim().toUpperCase().replace(/\d[A-Z]?$/, ""); }

  /** The filed SID: the first of the route's first three items that looks like one (as vatflow's sidFromRoute). */
  function sidFromRoute(route) {
    var t = String(route || "").toUpperCase().split(/[\s.]+/).filter(Boolean).slice(0, 3);
    for (var i = 0; i < t.length; i++) if (/^[A-Z]{3,5}\d[A-Z]?$/.test(t[i])) return t[i];
    return "";
  }

  /** The first fix of SID sid off runway end id (its runway transition, else the common part), or "". */
  function firstFix(nv, sid, id) {
    var p = nv && nv.procs && sid ? nv.procs[sid] || nv.procs[sidBase(sid)] : null;     // an older / newer revision: by its base
    if (!p || !p.transitions) return "";
    var num = id.replace(/[LCR]$/, ""), tr = p.transitions, legs = tr["RW" + id] || (/[LCR]$/.test(id) && tr["RW" + num + "B"]) || tr["RW" + num];
    if (!legs) for (var k in tr) if (/^RW/.test(k) && k.indexOf(num) === 2 && !legs) legs = tr[k];
    var fix = (legs && legs[0]) || (p.common && p.common[0]);
    return fix ? String(fix[0] || "") : "";
  }

  /** The nav data once it is loaded, else null. */
  function current() { return nav; }

  /** Loads vatflow.io's nav data once (cb(err, nav)); tried again at most every 10 minutes after a failure. */
  function loadNav(base, cb) {
    if (nav) { cb(null, nav); return; }
    if (navWait.length) { navWait.push(cb); return; }
    if (Date.now() - navTried < 600000) { cb(new Error("nav data not loaded")); return; }
    navTried = Date.now();
    navWait.push(cb);
    var got = {}, left = 0, failed = null;
    Object.keys(NAV_FILES).forEach(function (k) {
      left++;
      var x = new XMLHttpRequest();
      x.open("GET", base + "data/nav/" + NAV_FILES[k], true);
      x.timeout = 60000;
      x.onreadystatechange = function () {
        if (x.readyState !== 4) return;
        if (x.status === 200) { try { got[k] = JSON.parse(x.responseText); } catch (e) { failed = e; } }
        else failed = failed || new Error("nav " + NAV_FILES[k] + ": HTTP " + x.status);
        if (--left) return;
        if (!failed) nav = got;
        var w = navWait; navWait = [];
        w.forEach(function (f) { f(failed, nav); });
      };
      x.send();
    });
  }

  /** "hsl(200, 82%, 62%)" -> "#xxxxxx" (the sim's screens and old browsers take hex for sure). */
  function hex(hsl) {
    var m = /hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/.exec(String(hsl || ""));
    if (!m) return "#8c8c8c";
    var h = +m[1] / 360, s = +m[2] / 100, l = +m[3] / 100;
    function f(n) {
      var k = (n + h * 12) % 12, a = s * Math.min(l, 1 - l);
      var c = l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
      var v = Math.round(c * 255).toString(16);
      return v.length < 2 ? "0" + v : v;
    }
    return "#" + f(0) + f(8) + f(4);
  }

  /** Does a SID's published runway list (["08B", "10", ...]) take runway end id? */
  function sidTakes(list, id) {
    if (!list || !list.length) return true;
    var num = id.replace(/[LCR]$/, "");
    for (var i = 0; i < list.length; i++) {
      var r = String(list[i]).toUpperCase();
      if (r === id || r === num || (r === num + "B" && /[LR]$/.test(id))) return true;
    }
    return false;
  }

  /**
   * The sequence from one look at the feed. pilots: the VATSIM feed's; info: {icao, arp,
   * elevFt, runways, depIds (the departure ends in use), depSrc}; ops: VatflowOps' stored history;
   * nv: the nav data or null (then fixes are names only: every pair 3 miles in trail).
   */
  function compute(pilots, info, ops, nv, now) {
    var T = VatflowTaxiSeq, O = VatflowOps, es = O.ends(info.runways), fieldLL = [info.arp.lat, info.arp.lon];
    var dep = es.filter(function (e) { return (info.depIds || []).indexOf(e.id) >= 0; });
    if (!dep.length) dep = es;
    var rnavSids = (nv && nv.rnav && nv.rnav[info.icao]) || [], sidRwys = (nv && nv.sidRwys && nv.sidRwys[info.icao]) || {};
    var rules = (info.taxiCfg && info.taxiCfg.sidRules) || {};
    var fixCache = {};
    function fixOf(route) {
      if (fixCache[route]) return fixCache[route];
      var f;
      if (nv) f = T.departureFix({ route: route, icao: info.icao, fieldLL: fieldLL, procs: nv.procs, fixes: nv.fixes, navaids: nv.navaids });
      else {
        var sf = typeof VatflowStrips !== "undefined" ? VatflowStrips.sidFix(route, info.icao.slice(1), "").text.split(" ") : [];
        f = { sid: sf.length > 1 ? sf[0] : "", fix: sf[sf.length - 1] || "", bearing: NaN };
      }
      f.rnav = !!f.sid && rnavSids.indexOf(f.sid) >= 0;
      f.color = hex(T.courseColor(f.bearing));
      f.label = (f.sid ? f.sid + "." : "") + (f.fix || "?");      // BANNG3.LUCKK (the screens' font may have no middle dot)
      return (fixCache[route] = f);
    }
    function item(cs, type, route) {
      var f = fixOf(route || "");
      return { id: cs, fix: f.fix, bearing: f.bearing, wake: T.wakeOf(type), rnav: f.rnav, label: f.label, color: f.color, type: type, sid: f.sid,
        route: route || "" };
    }
    // departures that went in the last few minutes (they hold the next ones)
    var recent = ((ops && ops.deps) || []).filter(function (d) { return now - d.t < RECENT_S * 1000; }).map(function (d) {
      var it = item(d.cs, d.type, d.route);
      it.agoSec = Math.round((now - d.t) / 1000);
      it.end = d.end;
      return it;
    });
    var gone = {};
    ((ops && ops.deps) || []).forEach(function (d) { gone[d.cs] = true; });
    // the queues: departures here that have started taxiing, not yet rolling, each to its runway
    var queues = {};
    dep.forEach(function (e) { queues[e.id] = []; });
    (pilots || []).forEach(function (p) {
      if (!p || !p.flight_plan || typeof p.latitude !== "number") return;
      var a = O.ac(p);
      if (a.dep !== info.icao || gone[a.cs]) return;
      if (O.distNm(info.arp, a.lat, a.lon) > 4 || a.alt - (info.elevFt || 0) > 300 || a.gs >= O.ROLL_KT) return;
      var taxiing = (ops && ops.taxi && ops.taxi[a.cs]) || a.gs >= O.TAXI_KT;
      if (!taxiing) return;
      var it = item(a.cs, a.type, a.route), sid = it.sid || sidFromRoute(a.route);
      var ruled = rules[sidBase(sid)] || "", byRule = ruled ? es.filter(function (e) { return e.id === ruled; })[0] : null;
      var pub = sidRwys[sid] || sidRwys[sidBase(sid)];
      var cand = byRule ? [byRule] : dep.filter(function (e) { return sidTakes(pub, e.id); });
      if (!cand.length) cand = dep;
      var lined = O.onRunway(es, a, info.elevFt), best = lined, bd = Infinity;
      if (lined && !queues[lined.id]) lined = best = null;                 // crossing a runway not in use
      if (!best) cand.forEach(function (e) { var d = O.distNm(e, a.lat, a.lon); if (d < bd) { bd = d; best = e; } });
      if (!queues[best.id]) { queues[best.id] = []; dep.push(best); }       // a rule to a runway not in the list
      it.rwySrc = lined ? "LINED UP" : byRule ? "IDST" : pub ? "SID" : "NEAREST";
      it.ready = T.readySec({ lat: a.lat, lon: a.lon, moved: true, gs: a.gs }, best);
      if (lined) it.ready = 0;
      it.end = best;
      queues[best.id].push(it);
    });
    var model = { at: now, icao: info.icao, nav: !!nv, depIds: dep.map(function (e) { return e.id; }), depSrc: info.depSrc || "",
      runways: [], fixClocks: {}, seq: {} };
    dep.forEach(function (e) {
      var mine = recent.filter(function (d) { var de = es.filter(function (x) { return x.id === d.end; })[0]; return de && T.runwayRelation(de, e) === "same"; });
      var last = mine.length ? mine[mine.length - 1] : null;
      var q = queues[e.id];
      q.forEach(function (it) {
        var others = recent.filter(function (d) { return d !== last; }).map(function (d) {
          var de = es.filter(function (x) { return x.id === d.end; })[0];
          var r = {}; for (var k in d) r[k] = d[k];
          r.relation = de ? T.runwayRelation(de, e) : "far";
          return r;
        });
        it.floor = T.releaseFloor(it, others, T.DEFAULT_INTERVALS);
      });
      var res = T.sequenceRunway(q, { lastDep: last, intervals: T.DEFAULT_INTERVALS });
      var jumped = {};
      res.moves.forEach(function (m) { jumped[m.id] = true; });
      var rows = res.order.map(function (it, i) {
        var s = res.best.slots[i];
        model.seq[it.id] = { n: i + 1, rwy: e.id, color: it.color };
        return { n: i + 1, cs: it.id, type: it.type, wake: it.wake, fix: it.fix, label: it.label, color: it.color,
          t: Math.round(s.t), sec: Math.round(s.pair.sec || 0), kind: s.pair.kind, rule: s.pair.rule || "", held: !!s.held,
          jumped: !!jumped[it.id], ready: Math.round(it.ready || 0), first: firstFix(nv, it.sid || sidFromRoute(it.route), e.id), rwySrc: it.rwySrc || "" };
      });
      model.runways.push({ id: e.id, rows: rows, saved: Math.round(res.savedSec || 0),
        last: last ? { cs: last.id, type: last.type, wake: last.wake, fix: last.fix, label: last.label, color: last.color, ago: last.agoSec } : null });
    });
    model.fixClocks = T.fixClocks(recent, T.DEFAULT_INTERVALS);
    return model;
  }

  /** The stored sequence for an airport, if it is recent (under 2 minutes old). */
  function stored(icao, now) {
    var m = typeof VatflowStore !== "undefined" ? VatflowStore.get("DEPSEQ_" + icao, null) : null;
    return m && m.at && (now || Date.now()) - m.at < 120000 ? m : null;
  }

  /** "1:05" for seconds (never negative). */
  function mmss(sec) {
    var s = Math.max(0, Math.round(sec || 0));
    return Math.floor(s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
  }

  var KIND = { diverge: "DIV", same: "TRL", wake: "WAKE", unknown: "TRL", simul: "SIM", first: "" };

  return { loadNav: loadNav, current: current, compute: compute, stored: stored, hex: hex, sidTakes: sidTakes, mmss: mmss, KIND: KIND,
    loadTaxiConfig: loadTaxiConfig, taxiConfigFor: taxiConfigFor, normRwy: normRwy, sidBase: sidBase, sidFromRoute: sidFromRoute, firstFix: firstFix };
})();

@echo off
rem One-time setup: installs the Python package the tools use (SimConnect).
if not exist "%~dp0closures_helper.py" (
  echo The closures helper's files are not next to this file.
  echo Did you run it from inside the zip? Right-click the zip ^> Extract All, then run
  echo closures.bat from the extracted VATFLOW-Closures-Helper folder.
  pause
  exit /b 1
)
call "%~dp0_python.bat" || exit /b 1
echo Installing the SimConnect package for %PY% ...
%PY% -m pip install --upgrade -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo.
  echo Setup FAILED: pip could not install the SimConnect package ^(see the messages above^).
  pause
  exit /b 1
)
echo.
echo Setup done. Closures: start a flight with the tower cab, then run closures.bat.
echo Placement backup tool: run 2-adjust-KDCA.bat.
pause

@echo off
rem One-time setup: installs the Python package the tools use (SimConnect).
call "%~dp0_python.bat" || exit /b 1
echo Installing the SimConnect package for %PY% ...
%PY% -m pip install --upgrade -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo.
  echo Setup FAILED: pip could not install the SimConnect package ^(see the messages above^).
  pause
  exit /b 1
)
echo.
echo Setup done. Closures: start a flight with the tower cab, then run closures.bat.
echo Placement backup tool: run 2-adjust-KDCA.bat.
pause

"""
VATFLOW Tower Cab - closures helper for MSFS 2024 (Windows).

The cab's CLOSURES screen (any screen's MENU) is where runways and taxiways are closed. An
instrument page can't put objects in the sim, so this helper does it: it listens on
http://127.0.0.1:47640 for the cab's list and creates / removes the SimObjects through
SimConnect (barricades with red lights across closed taxiways, a few work vehicles on them,
a lighted X at each end of a closed runway).

  python closures_helper.py          run it while you fly (closures.bat); Ctrl+C or close to stop
  python closures_helper.py --dry    no sim: print what it would create / remove (for testing)
  python closures_helper.py --test [m]  put one of each object m meters (default 250) in front
                                     of the cab, to check that they show up (closures-test.bat)

While it runs: press Enter to put everything back (after restarting the flight, for example).
The last list is kept in closures_last.json and put back when the helper starts.

The objects come from the VATFLOW closure objects (package/SimObjects/Misc/vatflow_closure_*,
in the cab's project). Their titles are below; closures.json next to this file can name other
SimObjects instead, e.g. {"titles": {"dumpTruck": "ASO_Baggage_Cart01"}}.

MSFS 2024 shows a SimObject the project editor has upgraded ("Package asset conversion") only
when it is created with a livery (SimConnect_AICreateSimulatedObject_EX1), which needs the
SimConnect.dll of the MSFS 2024 SDK; Python-SimConnect bundles the 2020 one. The helper uses
the 2024 SDK's DLL when it finds it (closures.json "dll", the MSFS2024_SDK variable, or
C:/MSFS 2024 SDK) and creates with the livery in closures.json "livery" (default: the
object's default livery).

Needs:  pip install SimConnect      (as tower_place.py)
"""

import json
import math
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = 47640
LAST_FILE = os.path.join(HERE, "closures_last.json")
CONFIG_FILE = os.path.join(HERE, "closures.json")

# kind numbers as in common/closures.js (VatflowClosures.KINDS)
KINDS = {1: "barricade", 2: "closedX", 3: "workTruck", 4: "dumpTruck", 6: "dirtPile", 7: "rockPile", 8: "portaPotty"}
TITLES = {
    "barricade": "VATFLOW Closure Barricade",
    "closedX": "VATFLOW Closure Lighted X",
    "workTruck": "VATFLOW Closure Work Truck",
    "dumpTruck": "VATFLOW Closure Dump Truck",
    "dirtPile": "VATFLOW Closure Dirt Pile",
    "rockPile": "VATFLOW Closure Rock Pile",
    "portaPotty": "VATFLOW Closure Porta Potty",
}
MAX_OBJECTS = 400
WARNED = set()


# ---------------------------------------------------------------------------
# Pure helpers (no simulator needed)
# ---------------------------------------------------------------------------

def load_config(path=CONFIG_FILE):
    """closures.json: {"titles": {...}, "livery": "", "dll": "path to SimConnect.dll"}"""
    cfg = {}
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    titles = dict(TITLES)
    titles.update(cfg.get("titles", {}))
    cfg["titles"] = titles
    return cfg


def find_dll(cfg):
    """The MSFS 2024 SDK's SimConnect.dll (has the _EX1 create), or None."""
    tries = [cfg.get("dll")]
    for var in ("MSFS2024_SDK", "MSFS_SDK"):
        if os.environ.get(var):
            tries.append(os.path.join(os.environ[var], "SimConnect SDK", "lib", "SimConnect.dll"))
    tries.append(r"C:\MSFS 2024 SDK\SimConnect SDK\lib\SimConnect.dll")
    for t in tries:
        if t and os.path.isfile(t):
            return t
    return None


def ahead(lat, lon, hdg, dist_m, side_m=0.0):
    """The point dist_m in front of (lat, lon) facing hdg (true), side_m to the right."""
    h = math.radians(hdg)
    n = dist_m * math.cos(h) - side_m * math.sin(h)
    e = dist_m * math.sin(h) + side_m * math.cos(h)
    return lat + n / 111320.0, lon + e / (111320.0 * math.cos(math.radians(lat)))


def object_key(o):
    """One string per object: the same object in a new list keeps its place in the sim."""
    return "%d|%.6f|%.6f|%d" % (int(o["k"]), float(o["lat"]), float(o["lon"]), int(round(float(o["hdg"]))) % 360)


def clean(payload):
    """The cab's {icao, rev, objects: [{k, lat, lon, hdg}]}, checked; unknown kinds dropped
    (and said once: the cab is newer than this helper)."""
    objs, unknown = [], set()
    for o in (payload or {}).get("objects", [])[:MAX_OBJECTS]:
        try:
            k = int(o["k"])
            lat, lon, hdg = float(o["lat"]), float(o["lon"]), float(o.get("hdg", 0))
        except (KeyError, TypeError, ValueError):
            continue
        if k in KINDS and -90 <= lat <= 90 and -180 <= lon <= 180:
            objs.append({"k": k, "lat": lat, "lon": lon, "hdg": hdg % 360})
        elif k not in KINDS:
            unknown.add(k)
    if unknown and not unknown <= WARNED:
        WARNED.update(unknown)
        print("  The cab sent object types this helper doesn't know (%s): copy the helper folder from the"
              " latest closures zip." % ", ".join(str(k) for k in sorted(unknown)))
    return {"icao": str((payload or {}).get("icao", ""))[:8], "rev": int((payload or {}).get("rev", 0) or 0), "objects": objs}


def diff(have_keys, want):
    """(keys to remove, objects to create) to get from the objects in the sim to the list."""
    want_by_key = {}
    for o in want:
        want_by_key.setdefault(object_key(o), o)
    remove = [k for k in have_keys if k not in want_by_key]
    create = [o for k, o in want_by_key.items() if k not in have_keys]
    return remove, create


# ---------------------------------------------------------------------------
# Simulator side
# ---------------------------------------------------------------------------

class Sim:
    """Creates and removes SimObjects. Python-SimConnect only reports a new object's id
    through an environment variable, so objects are created one at a time."""

    def __init__(self, cfg=None):
        cfg = cfg or {}
        try:
            from SimConnect import SimConnect
            from SimConnect.Enum import SIMCONNECT_DATA_INITPOSITION
        except ImportError:
            sys.exit("Python-SimConnect is not installed: run 1-setup.bat (pip install SimConnect)")
        self.InitPos = SIMCONNECT_DATA_INITPOSITION
        self.livery = str(cfg.get("livery", ""))
        self.on_ground = int(cfg.get("on_ground", 1))
        self.ground = 0.0         # ground elevation under the cab, ft MSL (ground_ft)
        dll = find_dll(cfg)
        self.ex1 = None
        if dll:
            self.sm = SimConnect(library_path=dll)
            try:
                from ctypes import c_char_p, c_long
                f = self.sm.dll.SimConnect.SimConnect_AICreateSimulatedObject_EX1
                f.restype = c_long
                f.argtypes = [type(self.sm.hSimConnect), c_char_p, c_char_p, SIMCONNECT_DATA_INITPOSITION,
                              self.sm.dll.DATA_REQUEST_ID]
                self.ex1 = f
            except AttributeError:
                pass
        else:
            self.sm = SimConnect()
        print("SimConnect.dll: %s (%s)" % (dll or "the 2020 one bundled with Python-SimConnect",
                                          "create with livery" if self.ex1 else "create by title only"))

    def create(self, title, o):
        """Our objects have no contact points, so "on the ground" alone may leave them at the
        altitude given: they get the ground elevation under the cab (the airport is flat
        enough), not 0 ft MSL, which buried them at KDCA."""
        os.environ["SIMCONNECT_OBJECT_ID"] = ""
        rq = self.sm.new_request_id()
        alt, gnd = o.get("alt", self.ground), o.get("gnd", self.on_ground)
        if self.ex1:
            p = self.InitPos()
            p.Latitude, p.Longitude, p.Altitude = o["lat"], o["lon"], alt
            p.Pitch, p.Bank, p.Heading, p.OnGround, p.Airspeed = 0, 0, o["hdg"], gnd, 0
            self.ex1(self.sm.hSimConnect, title.encode(), self.livery.encode(), p, rq.value)
        else:
            self.sm.createSimulatedObject(title, o["lat"], o["lon"], rq, hdg=o["hdg"], gnd=gnd, alt=alt)
        for _ in range(60):
            v = os.environ.get("SIMCONNECT_OBJECT_ID", "")
            if v:
                return int(v)
            time.sleep(0.05)
        return None

    def remove(self, object_id):
        from ctypes.wintypes import DWORD
        rq = self.sm.new_request_id()
        self.sm.dll.AIRemoveObject(self.sm.hSimConnect, DWORD(object_id), rq.value)

    def read(self, var, unit):
        from SimConnect import Request
        req = Request((var, unit), self.sm, _time=0)
        for _ in range(30):
            if req.value is not None:
                break
            time.sleep(0.1)
        return req.value

    def position(self):
        """The user's (the cab's) lat, lon and true heading."""
        return [self.read(v, b"degrees") for v in (b"PLANE LATITUDE", b"PLANE LONGITUDE", b"PLANE HEADING DEGREES TRUE")]

    def ground_ft(self):
        """The ground elevation under the cab (ft MSL); kept for create()."""
        g = self.read(b"GROUND ALTITUDE", b"feet")
        if g is not None:
            self.ground = float(g)
        return self.ground

    def close(self):
        try:
            self.sm.exit()
        except Exception:
            pass


class DrySim:
    """--dry: prints instead of talking to the sim."""

    def __init__(self, cfg=None):
        self.n = 1000

    def position(self):
        return 38.8521, -77.0377, 0.0

    def ground_ft(self):
        return 15.0

    def create(self, title, o):
        self.n += 1
        print("  create %-28s %.6f %.6f hdg %3d alt %s gnd %s -> id %d" % (
            title, o["lat"], o["lon"], o["hdg"], o.get("alt", "ground"), o.get("gnd", 1), self.n))
        return self.n

    def remove(self, object_id):
        print("  remove id %d" % object_id)

    def close(self):
        pass


class Helper:
    def __init__(self, sim_factory, titles):
        self.sim_factory = sim_factory
        self.titles = titles
        self.sim = None
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.want = {"icao": "", "rev": -1, "objects": []}
        self.have = {}            # key -> object id in the sim
        self.error = ""
        self.respawn = False
        if os.path.exists(LAST_FILE):
            try:
                with open(LAST_FILE, encoding="utf-8") as f:
                    self.want = clean(json.load(f))
                print("Last closures (%s, %d objects) will be put back." % (self.want["icao"] or "?", len(self.want["objects"])))
            except (OSError, ValueError):
                pass
        self.wake.set()

    def status(self):
        with self.lock:
            return {"ok": 1, "icao": self.want["icao"], "rev": self.want["rev"], "count": len(self.have), "error": self.error}

    def set_list(self, payload):
        p = clean(payload)
        with self.lock:
            self.want = p
        try:
            with open(LAST_FILE, "w", encoding="utf-8") as f:
                json.dump(p, f)
        except OSError:
            pass
        print("%s: %d objects from the cab (rev %d)" % (time.strftime("%H:%M:%S"), len(p["objects"]), p["rev"]))
        self.wake.set()

    def connect(self):
        while self.sim is None:
            try:
                self.sim = self.sim_factory()
                print("Connected to MSFS. Ground under the cab: %.0f ft" % self.sim.ground_ft())
            except SystemExit:
                raise
            except Exception as e:
                self.error = "MSFS not found"
                print("Waiting for MSFS (%s) ..." % e)
                time.sleep(5)

    def sync(self):
        with self.lock:
            want = list(self.want["objects"])
        if self.respawn:
            self.respawn = False
            for oid in self.have.values():
                self.sim.remove(oid)
            self.have = {}
        remove, create = diff(set(self.have), want)
        for k in remove:
            self.sim.remove(self.have.pop(k))
        failed = set()
        for o in create:
            title = self.titles[KINDS[o["k"]]]
            if title in failed:
                continue
            oid = self.sim.create(title, o)
            if oid is None:
                failed.add(title)
                print("  could not create \"%s\": is the closure objects package installed?" % title)
                continue
            self.have[object_key(o)] = oid
        self.error = ("missing in the sim: " + ", ".join(sorted(failed))) if failed else ""
        if remove or create:
            print("  in the sim now: %d objects" % len(self.have))

    def run(self):
        self.connect()
        while True:
            self.wake.wait()
            self.wake.clear()
            try:
                self.sync()
            except Exception as e:     # lost the sim: reconnect and put everything back
                print("SimConnect error (%s): reconnecting" % e)
                if self.sim:
                    self.sim.close()
                self.sim, self.have = None, {}
                self.connect()
                self.wake.set()


def make_handler(helper):
    class Handler(BaseHTTPRequestHandler):
        def _send(self, code, body):
            data = json.dumps(body).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_OPTIONS(self):
            self._send(200, {})

        def do_GET(self):
            if self.path.startswith("/status"):
                self._send(200, helper.status())
            else:
                self._send(404, {"error": "not found"})

        def do_POST(self):
            if not self.path.startswith("/objects"):
                self._send(404, {"error": "not found"})
                return
            try:
                n = int(self.headers.get("Content-Length", 0))
                helper.set_list(json.loads(self.rfile.read(n).decode("utf-8") or "{}"))
            except ValueError as e:
                self._send(400, {"error": str(e)})
                return
            self._send(200, helper.status())

        def log_message(self, *args):
            pass

    return Handler


def test(sim, titles, dist=250.0):
    """Two rows of one of each object dist m in front of the cab, 12 m apart, centred: the near row
    "on the ground" at the ground elevation, the far row (30 m further) not "on the ground",
    at the ground elevation. Enter removes them."""
    lat, lon, hdg = sim.position()
    if lat is None:
        sys.exit("No position from the sim (is a flight loaded?)")
    ground = sim.ground_ft()
    print("Cab at %.6f %.6f, heading %d, ground %.0f ft." % (lat, lon, hdg, ground))
    ids = []
    for row, (d, gnd, label) in enumerate(((dist, 1, "NEAR row, on the ground"), (dist + 30, 0, "FAR row, at ground height"))):
        print("%s, %d m out:" % (label, d))
        for i, k in enumerate(sorted(KINDS)):
            la, lo = ahead(lat, lon, hdg, d, (i - (len(KINDS) - 1) / 2.0) * 12)
            oid = sim.create(titles[KINDS[k]], {"lat": la, "lon": lo, "hdg": (hdg + 90) % 360, "alt": ground, "gnd": gnd})
            print("  %-28s %s" % (titles[KINDS[k]], "id %d" % oid if oid is not None else "COULD NOT CREATE"))
            if oid is not None:
                ids.append(oid)
    input("Look out the front window (or drone camera). Press Enter to remove them ... ")
    for oid in ids:
        sim.remove(oid)
    time.sleep(0.5)


def main(argv):
    dry = "--dry" in argv
    cfg = load_config()
    factory = (lambda: (DrySim if dry else Sim)(cfg))
    if "--test" in argv:
        sim = factory()
        try:
            i = argv.index("--test")
            dist = float(argv[i + 1]) if i + 1 < len(argv) and argv[i + 1].replace(".", "").isdigit() else 250.0
            test(sim, cfg["titles"], dist)
        finally:
            sim.close()
        return
    helper = Helper(factory, cfg["titles"])
    server = ThreadingHTTPServer(("127.0.0.1", PORT), make_handler(helper))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print("VATFLOW closures helper on http://127.0.0.1:%d%s" % (PORT, " (dry run, no sim)" if dry else ""))
    print("Open CLOSURES on any cab screen. Press Enter to put everything back; Ctrl+C to stop.")

    def keys():
        for _ in sys.stdin:
            helper.respawn = True
            helper.wake.set()
    threading.Thread(target=keys, daemon=True).start()
    try:
        helper.run()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()


if __name__ == "__main__":
    main(sys.argv[1:])

@echo off
rem Runway / taxiway closures: puts the barricades, lighted X's and work vehicles the cab's
rem CLOSURES screen asks for into the sim. Keep this window open (minimized) while you fly.
if not exist "%~dp0closures_helper.py" (
  echo The closures helper's files are not next to this file.
  echo Did you run it from inside the zip? Right-click the zip ^> Extract All, then run
  echo closures.bat from the extracted VATFLOW-Closures-Helper folder.
  pause
  exit /b 1
)
call "%~dp0_python.bat" || exit /b 1
%PY% "%~dp0closures_helper.py"
pause

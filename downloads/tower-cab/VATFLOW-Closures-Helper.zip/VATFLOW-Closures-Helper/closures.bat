@echo off
rem Runway / taxiway closures: puts the barricades, lighted X's and work vehicles the cab's
rem CLOSURES screen asks for into the sim. Keep this window open (minimized) while you fly.
call "%~dp0_python.bat" || exit /b 1
%PY% "%~dp0closures_helper.py"
pause

VATFLOW Tower Cab - closures helper
===================================

The cab's CLOSURES screen (any screen's MENU) closes runways and taxiways. Cab screens can't
put objects into the sim, so this small helper runs on your PC beside MSFS and places the
barricades, lighted X's, work vehicles and site props for you. It only listens on your own
PC (127.0.0.1:47640). Windows only.

First time
  1. Install Python 3 (https://www.python.org/downloads/ - tick "Add python.exe to PATH").
  2. Double-click 1-setup.bat (installs the SimConnect package for Python).

Every session
  1. Free flight in the VATFLOW Tower Cab.
  2. Double-click closures.bat and leave its window open (minimized is fine).
  3. Pick CLOSURES on a cab screen. The bottom line turns green ("SIM HELPER ON").
     After restarting the flight, press Enter in the helper window to put everything back.

Objects not showing?
  - Installed or updated the cab while MSFS was running? Quit MSFS completely and start it
    again: MSFS doesn't draw new objects until it has fully restarted.
  - With the flight loaded, run closures-test.bat: it puts one of each object 250 m in
    front of the cab (Enter removes them).
  - The helper prefers the MSFS 2024 SDK's SimConnect.dll when it finds it. If yours is
    elsewhere, put {"dll": "D:\\path\\to\\SimConnect.dll"} in closures.json next to these files.

Only your own sim shows the closures; VATSIM pilots don't see them.
See the VATFLOW Tower Cab manual, chapter 12, for everything else.

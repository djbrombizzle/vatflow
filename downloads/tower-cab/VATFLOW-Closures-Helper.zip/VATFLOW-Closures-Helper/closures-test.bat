@echo off
rem Checks the closure objects: puts one of each 250 m in front of the cab (closures-test.bat 400: 400 m). Enter removes them.
if not exist "%~dp0closures_helper.py" (
  echo The closures helper's files are not next to this file.
  echo Did you run it from inside the zip? Right-click the zip ^> Extract All, then run
  echo closures.bat from the extracted VATFLOW-Closures-Helper folder.
  pause
  exit /b 1
)
call "%~dp0_python.bat" || exit /b 1
%PY% "%~dp0closures_helper.py" --test %*
pause

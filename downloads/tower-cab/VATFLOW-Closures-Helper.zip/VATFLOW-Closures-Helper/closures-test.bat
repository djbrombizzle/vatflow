@echo off
rem Checks the closure objects: puts one of each 250 m in front of the cab (closures-test.bat 400: 400 m). Enter removes them.
call "%~dp0_python.bat" || exit /b 1
%PY% "%~dp0closures_helper.py" --test %*
pause
